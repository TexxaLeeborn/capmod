package sEM2;

import java.util.Vector;

import repast.simphony.random.RandomHelper;

public class School extends Agent{
	
	/** Location (village) in this the school is located */
	protected Location location;
	
	/** Vector of all students enrolled in the schoool*/
	protected Vector<Individual> students = new Vector<Individual>();
	
	/** Capacity of the school for all grades. The number of students enrolled at the school CANNOT exceed this value */
	protected int capacity;
	
	/** Quality indicator of the school [0.0,1.0] where higher values are better. */
	protected float quality;
	
	/** Boolean to indicate whether the school is private (true) of public (false) */
	protected boolean privateschool ;
	
	/** The tuition fee to be paid by students. This is fix during the simulation, no adaption */
	protected float tuition; 
	
	/** Level of the school:<br> 1: primary<br> 2: lower secondary<br> 3: upper secondary<br> 4: university */
	protected int level;

	
	
	/**
	 * 
	 * @param city	In this city/village is the school located
	 * @param capacity Maximum number of students in the school
	 * @param quality Quality parameter (max=1, min=0)
	 * @param priv Binary indicator (true=private, false=public)
	 * @param tution Tuition fee in (only relevant for private schools)
	 * @param level Level of the school (1=prim, 2=low second, 3 = upper secondary, 4 = university)
	 */
	public School(Location city,int capacity, float quality, boolean priv, float tution,int level){
		this.location 		= city;
		this.capacity 		= capacity;
		this.quality		= quality;
		this.privateschool 	= priv;
		this.tuition		= tution;
		this.level 			= level;

		
		
		
		//System.out.printf("New school created in %s:\n\tLevel:%s\tQuality%s\tTution:%s\tPrivate:%s\tDelta:%s\n",this.location.getName(),level,quality,tution,priv,this.getDelta());
	}
	
	/**
	 * Enrolls the student if (and only if) the capacity is not yet attained and the students satisfied the criteria of the school (CRITERIA CONDITION NOY YET PROGRAMMED
	 * @param student
	 * @return
	 */
	public boolean enroll(Individual student){
		if(this.capacity>this.students.size()){
			// => capacity not yet attained
			this.students.add(student);
			student.reason_left_school=0;
			return true;
		}
		else{
			//System.out.printf("SCHOOL %s is full (capcity:%s; enrollment: %s)\n",this.toString(),this.capacity,this.students.size());
			student.comment+="School had no capacity|";
			return false;
		}
		
	}
	
	/**
	 * Takes the child out of the school and sets the reason of leaving
	 * @param student the individual that should be taken out of the school
	 * @param reason Reason for leaving the school: for definition of values see {@link Individual#reason_left_school}
	 * 
	 */
	public void quitSchool(Individual student,int reason){
		if(reason>0){
			student.reason_left_school=reason;
			
								
					
		}
		this.students.remove(student);
		student.school=null;
		}
	
	/**
	 * Computes the occupation of the school where 1 is full capacity enrollment. 
	 * @return
	 */
	public double getEnrollOverCapcity(){
		double result = (double) this.students.size() / (double) this.capacity;
		return result;
	}

	/**
	 * Gets the school specific delta from the array in Model.java
	 * @return Delta from Model.school_delta
	 */
	public double getDelta() {
		return Model.psiS[4*boolean2int(this.privateschool)+this.level-1];
	}

	/**
	 * Method to define the school quality based on whether the school is private or public. The idea is that the average
	 * quality is higher in private schools, but at the same time there is more variance. 
	 * @param privateSchool boolean for private (true) vs public (false) schools. 
	 * @param type integer: 1:primary, 2: lower secondary, 3: upper secondary, 4: tertiary education
	 * @return (float)  of the quality [0.0,1.0]
	 */
	public static float getRandomSchoolQuality(boolean privateSchool, int type ) {
		float quality = (float)0.0;
		
		if(type<4 & privateSchool==true){ // private schools (primary to upper secondary)
			quality = (float) RandomHelper.nextDoubleFromTo(0.75, 1.0);
		}
		else if(type==4){ // Tertiary education (both public and private)
			quality = (float) RandomHelper.nextDoubleFromTo(0.8, 1.0);
		}
		else{ // Public schools for primary to upper secondary. 
			quality = (float) RandomHelper.nextDoubleFromTo(0.7,0.9); 
		}
		
		return quality;
	}

	
	

}
