package sEM2;

import java.util.Vector;

import repast.simphony.space.continuous.ContinuousSpace;

public class Location {
	
	// Geographic location
	protected ContinuousSpace<Object> space;
	protected double xcoord;
	protected double ycoord;
	protected int ID;
	protected String name;
	
	
	// Infrastructure
	protected int type; // 1=Village, 2=Small town, 3=Large town, 4=Capital city
	protected Vector<School> 	schools 	= 		new Vector<School>();
	protected Hospital			hospital 	= 	null;
	
	
	
	
	
	/**
	 * 
	 * @param ID
	 * @param name
	 * @param xcoord
	 * @param ycoord
	 * @param space
	 */
	public Location(int ID,String name,int type,double xcoord,double ycoord, ContinuousSpace<Object> space){
		this.ID = ID;
		this.name=name;
		this.type=type;
		this.space=space;
		this.xcoord=xcoord;
		this.ycoord=ycoord;
	
	}

	/*
	 * Prints some basic information to the console
	 */
	public void describe(){
		System.out.printf("Location name: %s\t x=%s,y=%s\n",name,xcoord,ycoord);
	}


	/**
	 * Returns the name of the location
	 * @return Name
	 */
	public String getName() {
		return this.name;
	}



	/**
	 * Returns the list of all schools 
	 * @param years_educ Put 0=primary, 6=lower secondary, 9=upper secondary, 12=tertiary
 	 * @param privOK if true, then private schools are included
 	 * @param publicOK if true, then public schools are included
	 * @return vector of all schools
	 */
	public Vector<School> getListOfSchools(int years_educ, boolean privOK,boolean publicOK) {
		int level=0;
		switch(years_educ){
		case 0: level=1; break;
		case 6: level=2; break;
		case 9: level=3; break;
		case 12: level=4; break;
		}
		//System.out.printf("Searching schools of level %s in location %s (%s schools in all)",level,this.name,this.schools.size());
		Vector<School> list = new Vector<School>();
		for(School cand:this.schools){
			if(cand.level==level){
				if(cand.privateschool==true && privOK==true && cand.capacity>cand.students.size()){
					list.add(cand);
				}
				else if(cand.privateschool==false && publicOK==true &&  cand.capacity>cand.students.size()){
					list.add(cand);
				}
			} // end of if(cand.level==level)
		}
		//System.out.printf("\t found %s schools\n",list.size());
		return list;
		
		
	}
	
	/**
	 * Computes the distance between this location and the location in the argument
	 * @param partner Location to which we want to compute the distance
	 * @return double distance
	 */
	public double getDistance(Location partner){
		double distance = space.getDistance(space.getLocation(this), space.getLocation(partner));
		return distance;
		
	}

	/**
	 * Searches the highest quality school in the given location for the given level of schooling. 
	 * @param currentEduc years of completed schooling => this will be converted automatically to the level
	 * @return
	 */
	public School getBestSchoolByLevel(int currentEduc) {
		
		
		if(currentEduc>=18){
			return null;
		}
		else{
		int[] converter = {1,1,1,1,1,1,2,2,2,3,3,3,4,4,4,4,4,4};
		int requestedLevel=converter[currentEduc];
		
		//System.out.printf("I am searching the best school for level %s in location %s (number of schools=%s):\n", requestedLevel,this.name,this.schools.size());
		
		School bestSchool=null;
		float highestQuality=Float.NEGATIVE_INFINITY;
		for(School s:this.schools){
			if(s.level==requestedLevel){
				if(s.quality>highestQuality){
					highestQuality=s.quality;
					bestSchool = s;
				} // is better school
			} //end is the correct level
		} //end for loop
		
		
		
		return bestSchool;
		}
	}

	/**
	 * Returns the number of schools of the given type in the location. 
	 * @param type Type of school: (1=prim, 2=low second, 3 = upper secondary, 4 = university)
	 * @return number of schools as integer
	 */
	public int getNumberOfSchools(int type) {
		int n=0;
		for(School s:this.schools){
			if(s.level==type){
				n++;
			}
		}
		return n;
	}

	
}
