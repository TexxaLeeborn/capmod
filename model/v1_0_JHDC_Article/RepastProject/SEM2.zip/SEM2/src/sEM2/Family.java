package sEM2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;
import java.util.Vector;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.util.ContextUtils;

public class Family extends Agent  {
	
	// Location
	public Location location;
	protected ContinuousSpace<Object> space;
	protected double xcoord;
	protected double ycoord;
	protected int ID;
	
	// Members
	public Individual father;
	public Individual mother;
	protected Vector<Individual> children = new Vector<Individual>();
	
	// Characteristics
	protected 	float savings		=(float) 0.00;
	protected 	float savings_before=(float) 0.00;
	
	// Capabilities
	protected boolean capabIncomeAboveMin;
	protected boolean capabAblePayAllRecovery;
	protected boolean capabAblePayAllSchooling;
	
	// Temporary variables (for analytical purposes)
	protected 	double income 		= 0.00;
	protected 	double consumption 	= 0.00;
	protected 	double hce			= 0.00;
	protected 	float educ_exp		= (float) 0.00;
	protected double minconsumption = 0.0;
	protected int schoolingDecisionCase = 0; 
	
	
	
	
	
	
	
	
	
	


	/**
	 * Creates a new family (starting with the parents only)
	 * @param thislocation
	 * @param mother
	 * @param father
	 * @param bequest 
	 */
	public Family(Location thislocation, Individual mother, Individual father, double bequest) {
		
		if(thislocation==null){
			System.out.printf("PROBLEM WITH THE LOCATION: mother=%s, father=%s\n", mother.ID,father.ID);
			System.exit(0);
		}
		this.ID = Model.counter_famid;
		Model.counter_famid++;
		this.location = thislocation;
		this.mother = mother;
		this.father= father;
		mother.family = this;
		father.family = this;
		mother.partner=father;
		father.partner=mother;
		
		this.savings=(float) bequest;
		
		
		//this.describe();
		//System.out.printf("(Family.java:61) Family created: Location:%s, Father:%s,Mother:%s, Bequest:%s\n", this.location.name,this.father.ID,this.mother.ID,this.savings);
	}
	
	/**
	 * Creates a new single family when parents of the original family die and child has not yet found a partner
	 * @param thislocation
	 * @param individual
	 * @param bequest 
	 */
	public Family(Location thislocation, Individual individual, double bequest) {
		
		if(thislocation==null){
			System.out.printf("PROBLEM WITH THE LOCATION: mother=%s, father=%s\n", mother.ID,father.ID);
			System.exit(0);
		}
		this.ID = Model.counter_famid;
		Model.counter_famid++;
		this.location = thislocation;
		if(individual.female){
				this.mother = individual;
		}
		else{
				this.father=individual;
		}
		
		individual.family=this;
		
		
		this.savings=(float) bequest;
			
			
			
	
		
		}
	
	//Step: 95 stepCleanFamily()
	@ScheduledMethod(start=1,interval=1, priority=95) // Step: 95 Family.stepCleanFamily()
	public void stepCleanFamily(){

		
		for(Iterator<Individual> iterator = this.children.iterator();iterator.hasNext();){
			Individual me = iterator.next();
			if(me.dead==1 /*|| me.partner!=null*/){
				iterator.remove();
			}
		}
		if(this.getFamilySize()==0){
			@SuppressWarnings("unchecked")
			Context<Object> mycontext = ContextUtils.getContext(this);
			mycontext.remove(this);
		
		}
		
		this.savings_before = this.savings;
		
		
		
	
	}
	
	//Step: 98 stepFamilyProcreation
	@ScheduledMethod(start=1,interval=1, priority=98,shuffle=true)
	public void stepFamilyProcreation(){
		
		if(this.mother!=null && this.father!=null){
				if(mother.drawChild()){
					
					Individual child = new Individual(this.mother,this.father);
					Context<Object> mycontext = Model.context;
					
					mother.n_children++;
					mycontext.add(child); 
					this.addChild(child);
					
					//this.describe();	
				
			}
		}
	}
	
	
	//Step: 94 stepIncomeEduc
	@ScheduledMethod(start=1,interval=1,priority=94,shuffle=true)
	public void stepIncomeEduc(){
		//System.out.printf("\n\n\n------ START stepIncomeEduc() for a family %s %n",this.ID);
		//this.describe();
		
		// Clear periodical values: 
		this.hce 		= 0.0;
		this.educ_exp 	= (float) 0.0;
		
		
		// 1: Get income based on the Mincerian equation
				
				// Father's income
				this.income = getIncomeFather(true);
							
				// Mother's income in case she did not deliver recently
				Parameters params = RunEnvironment.getInstance().getParameters();
				int xiAge = params.getInteger("xiAge"); 
				int ageYoungestChild = getAgeYoungestChild();
				if(ageYoungestChild==999 || ageYoungestChild>=xiAge){
					this.income += getIncomeMother(true); 
				}
				
				// Children's income (if out of school and not willing to continue)
				for(Individual child:children){
					if(child.atSchool()==false & child.age>6 && child.school==null && child.willingContinueSchool==false){
						this.income += child.getSalary(true); 
					}
				}
				
				this.savings += this.income;
				//System.out.printf("Income: %s - Disposable income: %s\n",this.income,this.savings);
		
				
		
		// 2: Minimal consumption (only computation, not yet actual consumption)
				double minConsumption = params.getDouble("betaUrban");
				
				if(this.location.type==1){
					minConsumption = params.getDouble("betaRural") ;
				}
				minConsumption = Math.sqrt(this.getFamilySize())*minConsumption;
		
				this.minconsumption = minConsumption;

				
				this.capabIncomeAboveMin=(this.savings>this.minconsumption);
				
				
		
		// 3: Payment for health shocks
			
			
			substepHCE(params,minConsumption);
		
		
			
		// 4: Schooling decisions
			substepEducChildren(params, minConsumption);
			
			
			
			
			
			
			// Consumption above minimum consumption 
			
				// Define savings rate: 20% base and 5% additional for each enrolled and future enrolled child
				int count_children = 0;
				for(Individual child:children){
					if(child.atSchool()==true || child.age<=6){
						count_children++;
					}
				}
				
			double savingsRate = Math.min(0.8, 0.2+count_children*0.05);
				
				
			double thisconsumption = Math.min(this.savings, Math.max(minConsumption, (1-savingsRate)*this.savings));
		
			
			consume(thisconsumption);
			
			
			//System.out.printf("STEP ENDED WITH THE FOLLOWING CONSUMPTION PATTERN:\n\tIncome: %s\n\tConsumption: %s\n\t Educ: %s\n\t Health: %s\n",this.income,this.consumption,this.educ_exp,this.hce);
			
			
			
	} // end step IncomeEduc

	//Step: 94sub2: substepEducChildren
	private void substepEducChildren(Parameters params, double minConsumption) {
		
		
		
		// 4a: check if budget problems
		
		// Search kids for which we need a decision and compute the cost that this would incur
		Vector<Individual> toEnroll 	= new Vector<Individual>();
		Vector<Individual> toContinue 	= new Vector<Individual>();

		Double total_tuition = 0.0;
		
		
	
		for(Individual child:this.children){
			//System.out.printf("CHILD:%s\n",child.ID);
			if((child.age>=6 & child.atSchool()==false && child.educ_years==0) || ((child.atSchool()==false | child.willingContinueSchool) && (child.educ_years==6 | child.educ_years==9 | child.educ_years==12))){
				
				child.comment+="Check willing enroll";
				if(checkIfWillingToEnroll(child)==true){
					toEnroll.add(child);
					child.setAtSchool(true);
					total_tuition += getPrivateTuition(child);
					child.comment+="=>yes|";
					
				} // end if willing to enroll
				else{
					child.comment+="=>no|";
					child.willingContinueSchool=false;
					child.setAtSchool(false);
					if(child.school!=null){
						child.school.quitSchool(child,-1);
					}
					
				}
				
			}
			else if(child.atSchool() && child.educ_years<16){ // within grade
				// compute tuition to pay
				
				child.comment+="continue |";
				//System.out.printf("CHILD ID =%s\n",child.ID);
				total_tuition += child.school.tuition;
				toContinue.add(child);
				
			}
			else if(child.atSchool() && child.educ_years==16){ // finished with the school
				child.setAtSchool(false);
				child.reason_left_school=1;
				
			}
			
			
			
		} // end loop through children
		
	
		
		
		// SPECIAL CASE: family without children: parents might still go to school
		if(this.children.size()==0){
			// FATHER
			if(father!=null && father.atSchool()){
				//father.comment+="Father at school| ";
				if(father.educ_years==6 | father.educ_years==9 | father.educ_years==12){
					if(checkIfWillingToEnroll(father)){
						father.school=null;
						toEnroll.add(father);
						//father.comment+="Added to toEnroll|";
					}
					else{
						//father.comment+="NOT WILLING TO CONTINUE|"; 
						father.reason_left_school = 13;
						father.setAtSchool(false);
						father.school=null;
					}
				}
				else if(father.educ_years==16){
					father.school.quitSchool(father,1);
					father.school=null;
					father.setAtSchool(false);
					//father.comment+="Not more educ available|";
				}
				else{
					toContinue.add(father);
					//father.comment+="Shall continue school|";
				}
			}
			// Mother
			if(mother!=null && mother.atSchool()){
				//mother.comment+="Mother at school| ";
				if(mother.educ_years==6 | mother.educ_years==9 | mother.educ_years==12){
					if(checkIfWillingToEnroll(mother)){
						toEnroll.add(mother);
						mother.school=null;
						
						//mother.comment+="Added to toEnroll|";
					}
					else{
						mother.reason_left_school = 13;
						mother.setAtSchool(false);
						mother.school=null;
					}
				}
				else if(mother.educ_years==16){
					mother.school.quitSchool(mother,1);
					mother.school=null;
					mother.setAtSchool(false);
					//mother.comment+="Not more educ available|";
				}
				else{
					toContinue.add(mother);
					//mother.comment+="Shall continue school|";
				}
			}
			
			/*if(toEnroll.size()>0 | toContinue.size()>0){
				System.out.printf("SPECIAL CASE, family with parents in school (%s)",this.toString());
				this.describe();
			}*/
		}
		 
		
		
		// Check who is in which list
		for(Individual i:toEnroll){
				i.comment+="Onlist: enroll|";
		}
		for(Individual i:toContinue){
			i.comment+="Onlist:continue|";
		}
		
		
		
		
		
		if(this.savings-minConsumption-total_tuition>0.0){ // no financial constraint: all continue or enroll
			this.capabAblePayAllSchooling=true;
			this.schoolingDecisionCase=1;
			float enrollCost = (float)enroll(toEnroll,params,this.savings);
			//System.out.printf("enroll cost in the main method:%s\n", enrollCost);
			this.savings-=enrollCost;
			this.educ_exp +=enrollCost;
			continueSchool(toContinue);
			
		}
		else{ // financial problems: let's see how to proceed
			this.capabAblePayAllSchooling=false;
			double costCont = getCostContinue(toContinue);
			if(this.savings-minConsumption-costCont>0){ // enough for all to continue and to enroll in public schools
				this.schoolingDecisionCase=2;
				continueSchool(toContinue);
				float enrollCost = (float)enroll(toEnroll,params,this.savings-minConsumption);
				this.savings-=enrollCost;
				this.educ_exp +=enrollCost;
			}
			else{ // not enough just by sending enrollees to public schools
				
				if(this.savings-minConsumption>0){
					// We now try to change already enrolled students to public schools instead of private schools
					for(Individual child:toContinue){
						if(this.savings-minConsumption-costCont>0){ // avoid changing too many
							this.savings	-=child.school.tuition;
							this.educ_exp 	+= child.school.tuition;
						}
						else{
							// Downgrade the child to public school
							child.capabDowngradeToPublic=true;
							enroll(child, false);
							//System.out.printf("I had to downgrade child with ID=%s\n",child.ID);
						}
						
						
					}
					
				}
				else{
					
				
				
				
				
				//System.out.printf("FOO: SIZE before:%s: ",toEnroll.size());
				Collections.sort(toEnroll,new ChildComparatorAge());	// sort the child
				//System.out.printf("size after:%s: ",toEnroll.size());
				
				for(Individual child:toEnroll){
					if(this.savings-minConsumption-costCont>0){ // ensures that not too many kids are taken out
						child.setAtSchool(false); // take out of school (rather: don't send to next level)
						child.school.quitSchool(child,4);
						
						double childincome = child.getSalary(true);
						this.savings += childincome;
						this.income +=childincome;
					}
					else{
						this.savings	-= enroll(child,false);
					}
				}
				
				if(this.savings-minConsumption-costCont>0){ // after sending children to labour market, continue with the others 
					this.schoolingDecisionCase=3;
					continueSchool(toContinue);
					float enrollCost = (float)enroll(toEnroll,params,this.savings);
					this.savings-=enrollCost;
					this.educ_exp +=enrollCost;
					}
				else{ // worst case scenario
					this.schoolingDecisionCase=4;
					float gainNeeded1=(float) -(this.savings-minConsumption-costCont);
					float gainNeeded2=(float) -(this.savings-minConsumption-costCont);

					// Check how many should be taken out of I order by the economic benefit
					Collections.sort(toContinue,new ChildComparatorEconGain());	// sort the child
					int N_out_1 = 0;
					for(Individual child:toContinue){
						if(gainNeeded1>0){
							gainNeeded1 -= child.school.tuition + child.getSalary(false);
							N_out_1++;
						}
					}
					// Check how many should be taken out of I order by the time to graduation
					Collections.sort(toContinue,new ChildComparatorTime2Grad());	// sort the child
					int N_out_2 = 0;
					for(Individual child:toContinue){
						if(gainNeeded2>0){
							gainNeeded2 -= child.school.tuition + child.getSalary(false);
							N_out_2++;
						}
					}
					
					// Which option is better (less childen out of school)?
					if(N_out_2>N_out_1){ // econ option (1) is better
						Collections.sort(toContinue,new ChildComparatorEconGain());	// sort the child
					}
					else{
						Collections.sort(toContinue,new ChildComparatorTime2Grad());	// sort the child
					}
					
					
					for(Individual child:toContinue){ //take out of school
						if(this.savings-minConsumption-costCont<0){
							child.setAtSchool(false);	// take out of school
							child.reason_left_school=4;
							costCont 		-= child.school.tuition;	// reduce the 'continuation cost'
							double 	childincome = child.getSalary(false);	// increase disposable income
							this.savings 	+=	childincome; 
							this.income		+= childincome;
							child.school.quitSchool(child,4);				// definitely take out of school
							}
						else{ // those remaining at school
							this.savings	-=child.school.tuition;
							this.educ_exp 	+=child.school.tuition;
							
						}
					} // end take out of school those already enrolled (until ok, then let them continue)
					
					

					} // end worst case scenario
					} // End of else to changing from private to public
				} // end not enough just to send enrollees to public schools
		} // end financial problems

		
		for(Individual child:this.children){
			if(child.atSchool()==true && child.school==null){
				child.setAtSchool(false); 
			}
		}
	
		//System.out.printf("End of substep education: expenditure_education:%s\n",this.educ_exp);
	
	} // end sub-step education
	

	//Step: 94sub1: substepHCE
	private void substepHCE(Parameters params,double minConsumption) {
		Vector<Individual> patients = new Vector<Individual>();
		if(father!=null && father.health_status<1.0){
			patients.add(father);
		}
		
		if(mother!=null && mother.health_status<1.0){
			patients.add(mother);
		}
		
		for(Individual c:this.children){
			if(c.health_status<1.0){
				patients.add(c);
			}
			
		}
		
		Collections.sort(patients,new ChildComparatorAge());	// sort the patients

		double tau = params.getDouble("tau"); 
		
		//System.out.printf("Family %s health services requirements\n",this.hashCode());
	
		
		// Pay full recovery if possible: loop through all, starting with the youngest
		this.capabAblePayAllRecovery=true; // set the value to true, if in the loop they are not able to pay, it will turn false again
		for(Individual i:patients){
			double recovery = Math.max(0.0,1.0- i.health_status); // how much recovery is needed
			
			//System.out.printf("\t For individual %s (age=%s): HS=%s => recovery=%s\n",i.hashCode(),i.age,i.health_status,recovery);
			double cheapest = Double.MAX_VALUE;		// the cost at the cheapest (to be defined) hospital
			Hospital bestHosp = null; 				// Link to the cheapest (to be defined) hospital
			
			// Loop over localities (=hospitals) to find the best treatment location
			for(Location l:Model.locations){
				double costRecovery = l.hospital.getCostTreatment(recovery);
				double costTransport = this.location.getDistance(l) * tau ;
				double totalCost = costRecovery + costTransport ;
				if(totalCost<cheapest){
						cheapest = totalCost;
						bestHosp = l.hospital;
				}
				//System.out.printf("\t\t%s => treatment: %s, transport: %s => total %s\n",l.name,costRecovery,costTransport,costRecovery+costTransport);
			}
			
			
			
			
			// Get the medical treatment
			//System.out.printf("Before treatment: Indiv HS=%s, Savings: %s (cheapest: %s)\n",i.health_status,this.savings,cheapest);
			
			// Check if sufficient money available (Capability)
			i.capabFullRecoveryPossible=(cheapest<=this.savings-minConsumption);
			if(i.capabFullRecoveryPossible==false){
				this.capabAblePayAllRecovery=false; // set's the family level measure of capability to false
			}
			cheapest = Math.max(0, Math.min(this.savings-minConsumption, cheapest)); // Here we limit the spending to the available amount of money
			
			
			
			
			
			//System.out.printf("Cheapest: %s\n",cheapest);
			
			if(cheapest>=1.0){ // This is a small hack to avoid inifinitely small amounts. There is virtually no recovery for 1 peso
				i.health_status = (float) Math.min(1.0, i.health_status+i.getTreatment(bestHosp,cheapest));
				this.savings	-=cheapest;
				this.hce		+= cheapest;
				i.hce  = cheapest;
				
			}
			//System.out.printf("After treatment: Indiv HS=%s, Savings: %s\n---\n",i.health_status,this.savings);
		
		} // end loop over individuals (patients)
		
		
	}
	
	

	/**
	 * Family consumes => savings adapted and variable consumption updated
	 * @param thisconsumption
	 */
	private void consume(double thisconsumption) {
		this.savings-=thisconsumption;
		consumption = thisconsumption;
	}

	/**
	 * Computed the cost of enrolling this child to a private school.
	 * @param child
	 * @return
	 */
	private double getPrivateTuition(Individual child) {
		double result = 0.0; 
		switch(child.educ_years){
			case 0: result = Model.tuition[1]; break;
			case 6: result = Model.tuition[2]; break;
			case 9: result = Model.tuition[3]; break;
			case 12: result = Model.tuition[4]; break;
		}
		return result;
	}


	/**
	 * Returns the cost if all enrolled children would continue. 
	 * @param toContinue
	 * @return
	 */
	 
	private double getCostContinue(Vector<Individual> toContinue) {
		
		double cost = 0.0;
		for(Individual child:toContinue){
			if(this.ID==8){
				System.out.printf("Indiv-%s (cost:%s)",child.ID,child.school.tuition);
			}
			cost += child.school.tuition;
		}
		
		return cost;
	}


	/**
	 * All children in the list will continue at the same school. 
	 * @param toContinue
	 */
	private void continueSchool(Vector<Individual> toContinue) {
		for(Individual child:toContinue){
			this.savings	-=child.school.tuition;
			this.educ_exp 	+= child.school.tuition;
			//System.out.printf("Continuing, costs me %s (before:%s, after%s)\n",child.school.tuition,backup,this.educ_exp);
		}
	}

	/**
	 * 
	 * @param toEnroll Vector<Individual> of children to be enrolled
	 * @param params system parameters
	 * @param budget maximum amount of tuition fees
	 * @return cost of enrollment (does not automatically reduce the savings!!)
	 */
	private double enroll(Vector<Individual> toEnroll,Parameters params,double budget) {
		// Enroll children to schools
					double cost = 0.0;
					if(toEnroll.size()>0){
						Collections.shuffle(toEnroll,new Random(params.getInteger("randomSeed"))); 
						for(Individual child:toEnroll){
							
							child.comment+="Try to enroll |";
							
							if(child.atSchool()==true){
								double costPrivate = getPrivateTuition(child);
							Vector<School> availableSchools = new Vector<School>();
							
							// Check first if there are private schools available (only if the cost allows it)
							if(budget-cost-costPrivate>=0){	// => can send child to private school
								child.comment+="Try private |";
								availableSchools = this.location.getListOfSchools(child.educ_years,true,false); 
								if(availableSchools.size()>0){
									child.comment+="Found "+availableSchools.size()+" priv. schools";
								}
							}
							
							// In case no private school available (or payable), look for public schools. 
							if(availableSchools.size()==0){ // can happen if no private school allowed OR available
								child.comment+="Try public |";
								availableSchools = this.location.getListOfSchools(child.educ_years,false,true); 
							}
							
							// If there are schools (any type), then enroll
							if(availableSchools.size()>0){
								child.comment+="Found "+availableSchools.size()+" school(s) |";
								//System.out.printf("Let's see which school accepts the child\n");
								Collections.shuffle(availableSchools,new Random(params.getInteger("randomSeed")));
								
								int runner=0;
								boolean cont=true;
								while(cont){
									School currentschool = availableSchools.get(runner);
									if(currentschool.enroll(child)==true){
										cont=false;
										child.school=currentschool;
										child.setAtSchool(true);
										cost+=currentschool.tuition;
										//System.out.printf("\t School %s accepted child %s (tuition=%s)\n",currentschool.toString(),child.toString(),currentschool.tuition);
									}
									else{
										//System.out.printf("\t School %s REJECTED child %s\n",currentschool.toString(),child.toString());
										runner++;
										if(runner>=availableSchools.size()){
											cont=false;
											
											child.setAtSchool(false);
											child.reason_left_school=5;
											
											//System.out.printf("\t =>WE COULD NOT FIND ANY SCHOOL FOR THIS CHILD (%s)!!!! AT school = %s\n",child.toString(),child.atschool);
										}
										
									}
									} // end while
								} // if # of schools >0
							else{
								child.comment+="NOT Found school |";
								child.reason_left_school=5; 
								child.setAtSchool(false);
								//System.out.printf("\t =>WE COULD NOT FIND ANY SCHOOL FOR THIS CHILD (%s)!!!! AT school = %s (Family.java:689)\n",child.ID,child.atSchool());
							}
							}	// if atschool==true (double check for the case of taking children out of the school)
							} // end loop through children
						} // end enroll children to school
					
					//System.out.printf("Total cost of enrollment: %s%n",cost);
					
			
				
	return cost;	
	}
	
	
	/**
	 * Enrolls a single child (just for particular cases)
	 * @param child
	 * @param privatSchool whether or not private schools should be considered. NO BUDGET CHECK IS MADE, THUS MAKE SURE THEY HAVE THE MONEY
	 * @return
	 */
	public double enroll(Individual child, boolean privateSchool){
		Vector<School> availableSchools = new Vector<School>();
		double cost = 0.0;
		if(privateSchool){	// => can send child to private school
			availableSchools = this.location.getListOfSchools(child.educ_years,true,false); 
		}
		if(availableSchools.size()==0){ // can happen if no private school allowed NOR available
			availableSchools = this.location.getListOfSchools(child.educ_years,false,true); 
		}
		if(availableSchools.size()>0){
			//System.out.printf("Let's see which school accepts the child\n");
			Parameters params = RunEnvironment.getInstance().getParameters();
			Collections.shuffle(availableSchools,new Random(params.getInteger("randomSeed")));
			
			int runner=0;
			boolean cont=true;
			while(cont){
				School currentschool = availableSchools.get(runner);
				if(currentschool.enroll(child)==true){
					cont=false;
					child.school=currentschool;
					child.setAtSchool(true);
					cost+=currentschool.tuition;
				}
				else{
					
					runner++;
					if(runner>=availableSchools.size()){
						cont=false;
						child.setAtSchool(false);
						child.reason_left_school=5;
						}
				}
				} // end while
			} // if # of schools >0
			else{
				child.setAtSchool(false);
				child.reason_left_school=10;
				child.school=null;
				
			}
		
		return cost;	
	}


	/**
	 * Method to check whether the family (or the child) wants to enroll for the next level
	 * @param child
	 * @return
	 */
	boolean checkIfWillingToEnroll(Individual child) {
		
		
		if(child.educ_years<9){ // parental decision
			if(child.getParentalAspiration()>child.educ_years || child.educ_years<6){
				child.comment+="parents want him/her to continue|";   
				return true;
			}
			else{
				child.comment+="parents no longer want more";
				child.reason_left_school=2; // too low parental aspirations
				return false;
			}
		}
		else{ //child's decision
			//System.out.printf("Asking the child: current educ: %s   aspirations:%s ====> ",child.years_educ,child.aspiration_educ);
			if(child.aspiration_educ>child.educ_years){
					//System.out.printf("CONTINUE\n");
				return true;
			}
			else{
				//System.out.printf("DROP OUT\n");
				child.reason_left_school=3; // too low aspirations of the child
				child.setAtSchool(false);
				
				return false;
			}
			
		}
		
		
	}


	/**
	 * Return the income of the father;
	 * @return
	 */
	private Float getIncomeFather(boolean stochastic) {
		if(this.father==null){
			return (float) 0.00;
		}
		else{
			return this.father.getSalary(stochastic);
		}
	}

	/**
	 * Return the income of the mother;
	 * @return
	 */
	private Float getIncomeMother(boolean stochastic) {
		if(this.mother==null){
			return (float) 0.00;
		}
		else{
			return this.mother.getSalary(stochastic);
		}
	}

	/**
	 * Return the age of the youngest child in the family. If there is not child, the function returns 999	
	 * @return age of youngest child
	 */
	private int getAgeYoungestChild() {
		int result = 999;
		if(this.children.size()>0){
			for(Individual thischild:this.children){
				if(thischild.age<result){
					result = thischild.age;
				}
			}
			
		}
		
		return result;
	}


	/**
	 * Adds a child to the family and 
	 * @param child
	 */
	public void addChild(Individual child){
		this.children.add(child);
		child.family = this;
		
	}
	
	
	
	
	/**
	 * Returns the family structure as array (int), where the first value is the number of fathers (0 or 1), 
	 * the second for the mother (0 or 1) and the third is the number of children
	 * @return int[n_father,n_mother,n_children]
	 */
	public int[] getFamilyStructure(){
		int[] result = {0,0,0};
		
		if(this.father!=null){
			result[0]=1;
		}
		if(this.mother!=null){
			result[1]=1;
		}
		result[2] = this.children.size();
		
		return result;
	}
	
	/**
	 * Prints a description of the family in the console
	 */
	public void describe(){
		System.out.printf("FAMILY DESCRIPTION (ID:%s) \n\tSavings: %s, Location: %s, N(children)=%s\n",this.ID,this.savings,this.location.name,children.size());
		
		// FATHER
		System.out.printf("\tFATHER:  ");
			if(this.father==null){
				System.out.printf("N/A\n");
			}
			else{
				this.father.describe();
			}
		//MOTHER
		System.out.printf("\tMOTHER:  ");
		if(this.mother==null){
			System.out.printf("N/A\n");
		}
		else{
			this.mother.describe();
		}
		
		// CHILDREN
		System.out.printf("\tCHILDREN:");
		for(Individual c:this.children){
			c.describe();
		}
		System.out.println("----- END OF FAMILY DESCRIPTION ----");
	}
	
	/**
	 * Prints a description of the family in the console
	 */
	public void describeShort(){
		System.out.printf("FAMILY (ID:%s):", this.ID);
		
		System.out.printf("\tFATHER:  ");
			if(this.father==null){
				System.out.printf("Father=N/A\t");
			}
			else{
				System.out.printf("Father=%s\t",this.father.ID);
			}
		System.out.printf("\tMOTHER:  ");
		if(this.mother==null){
			System.out.printf("Mother=N/A\t");
		}
		else{
			System.out.printf("Mother=%s\t",this.mother.ID);
		}
		System.out.printf("\tCHILDREN:");
		for(Individual c:this.children){
			System.out.printf("%s, ",c.ID);
		}
		//System.out.println("----- END OF FAMILY DESCRIPTION ----");
	}


	/**
	 * Returns the number of family members
	 * @return
	 */
	public int getFamilySize() {
		int[] array = this.getFamilyStructure();
		int result = array[0]+array[1] + array[2];
		return result;
	}
	
	/**
	 * Returns the number of children of this family still living in the family. 
	 * @return
	 */
	public int getNChildrenLivingInFamily(){
		int n=0;
		for(Individual child:this.children){
			if(child.family ==this){
				n++;
			}
		}
		return n;
	}
	
	/** 
	 * Returns the family income as is, not normalised nor equivalised. 
	 * @return double income
	 */
	public double getFamilyIncome(){
		return this.income;
	}
	
	/**
	 * Returns 1 for each family (for counting purposes)
	 * @return
	 */
	public int isFamily(){
		return 1;
	}

	/**
	 * Return the location of the family
	 * @return
	 */
	public Location getLocation() {
		return this.location;
	}
	/**
	 * Returns 1 if the family is in the reproductive age and 0 otherwise
	 * @return
	 */
	public int isReproductiveFamily(){
		if(this.mother!=null && this.mother.age<=45 && this.father!=null){
			return 1;
		}
		else{
			return 0;
		}
	
	}
	/**
	 * Return the last saved consumption of the family (absolute values, not per capita!!)
	 * @return
	 */
	public double getConsumption(){
		return this.consumption;
	}
	/**
	 * Return the savings of the family
	 * @return
	 */
	public double getSavings(){
		return this.savings;
	}

	/**
	 * Distributes the current savings to all children of the family and adds it to the savings of that family. That family can 
	 * be in fact the same family, if the children did not yet leave the family. 
	 */
	public void bequest() {
		
		double amount = this.savings;
		//System.out.printf("I make the BEQUEST now. There are %s units to distribute\n\t => let's see how many people receive something... \n",amount);
		
		this.savings = (float) 0.0;
		ArrayList<Individual> originalChildren = getOriginalChildren();
		
		
		int n_children = originalChildren.size();
		double amount_per_child = amount/(double)n_children;
		//System.out.printf("==> there are %s people, each of which gets %s\n",originalChildren.size(),amount_per_child);
		
		for(Individual child:originalChildren){
			if(child.family!=null){
				child.family.savings+=amount_per_child;
			}
		}
		

		
	}

	/**
	 * Generates an ArrayList&lt;Individual&gt; with all the children of the family, independently if they are still living within the family.
	 * @return
	 */
	protected ArrayList<Individual> getOriginalChildren() {
		ArrayList<Individual> result = new ArrayList<Individual>();
		@SuppressWarnings("unchecked")
		Context<Object> mycontext = ContextUtils.getContext(this);
		for( Object o:mycontext.getObjects(Individual.class)){
			Individual c = (Individual)o;
			if(c.familyOriginal==this && c.dead==0){
				result.add(c);
			}
		
		}
		return result;
	}

	/** 
	 * Used only when the second of the parents dies. All remaining children will automatically be transfered to a new single-individual family. 
	 */
	public void splitFamily() {
		// Adding to context
			@SuppressWarnings("unchecked")
			Context<Object> mycontext = ContextUtils.getContext(this);
			
			for(Individual child:this.children){
				Family newfamily = new Family(this.location,child,0.0);
				mycontext.add(newfamily);
				
				// move on the grid
				float xcoord = (float) Math.min(49.999,Math.max(0,newfamily.location.xcoord + RandomHelper.createNormal(0, 1).nextDouble()));
				float ycoord = (float) Math.min(49.999,Math.max(0,newfamily.location.ycoord + RandomHelper.createNormal(0, 1).nextDouble()));
						
				newfamily.move(xcoord,ycoord);
			}
		this.children.clear();
		
	}

	/**
	 * Deletes all pointings to other objects, in particular it sets mother=father=null and clears the vector of children. 
	 */
	public void clearFamilyMembers() {
		this.mother=null;
		this.father=null;
		this.children.clear();
		
	}
	
	/**
	 * Returns the boolean capDowngradeToPublic as integer (dummy)
	 * @return
	 */
	public int getAblePayAllRecovery(){
		return boolean2int(this.capabAblePayAllRecovery);
	}

}
