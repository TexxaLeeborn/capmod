package sEM2;
//TEST

import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.ContinuousSpace;

public class Agent {
	
	public static ContinuousSpace<Object> space;
	protected static final float prob_child[][] = new float[46][9];
	protected static final float mincer[][] = new float[13][4];




/**
 * Converts years of schooling to the different classes (primary, complete secondary, tertiary, etc)
 * @param years
 * @return level (according to fertility matrix
 */
public static int educYearToLevel(int years){
	int[] array = {0,1,1,1,1,1,2,3,3,4,5,5,6,6,6,6,7,7,7,7,7,7,7};
	return array[years];
}

/**
 * Converts 0/1 to false/true. If the argument is equal to 1, it returns TRUE, otherwise FALSE. 
 * @param x integer
 * @return boolean true/false
 */
public static boolean Int2Boolean(int x) {
	if(x==1){
		return true;
	}
	else{
		return false;
	}
}

/**
 * Converts true/false to 0/1 . If the argument is equal to TRUE, it returns 1, otherwise 0. 
 * @param x boolean
 * @return int 0/1
 */
public static int boolean2int(boolean x) {
	if(x==true){
		return 1;
	}
	else{
		return 0;
	}
}

/**
 * Prints a matrix in the console
 * @param matrix
 */
public static void PrintMatrix(float[][] matrix){
	
	int rows = matrix.length;
	int cols = matrix[1].length;
	
	for(int row=0;row<rows;row++){
		for(int col=0;col<cols;col++){
			System.out.printf("%5.3f  ",matrix[row][col]);
		}
		System.out.printf("%n");
	}
	System.out.printf("There are %s columns and %s rows\n",cols,rows);
	

}

/**
 * Based on the initial personality, a new personality is generated with a certain deviation, but always in the range of 0/1
 * @param personality
 * @return float personality
 */
public static float newPersonality(float personality) {
	double sigmaPers = RunEnvironment.getInstance().getParameters().getDouble("sigmaPers"); 
	float newpersonality = personality + (float)RandomHelper.createNormal(0,sigmaPers).nextDouble();
	newpersonality = Math.min(1, Math.max(0,newpersonality));
	return newpersonality;
}

/**
 * Same as newPersonality(float personality), but first computed the average of the two inputs
 * @param p1 Personality of the first individual (e.g. father)
 * @param p2 Personality of the second individual (e.g. mother)
 * @return (float) personality
 */
public static float newPersonality(float p1,float p2){
	float average = (p1+p2)/2;
	return newPersonality(average);
}

/**
 * Move the agent to x,y on the grid
 * @param x x-coordinate
 * @param y y-coordinate
 */
public void move(double x, double y){
	space.moveTo(this,x, y);

}







}