package sEM2;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Vector;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import repast.simphony.util.ContextUtils;




public class Individual extends Agent  {
	protected int ID;
	
	// Personal characteristics
	protected byte		originalIndiv=0;
	protected boolean 	female;
	protected int 		age;
	protected float 	IQ;
	protected int 		educ_years;
	/** Counterfactual years of schooling if always going to school */
	protected int 		educ_yearsCF;
	protected int 		failedgrades=0;
	protected int 		failedGradesLevel=0;
	protected float 	human_capital; // 1 unit => 1 year of normal schooling! (e.g. high quality)
	/** Counterfactual human capital if going to the best school always (=capability) */
	protected float 	human_capitalCF;
	protected float 	health_status;
	protected float 	income;
	protected float 	personality;
	/**
	 * Boolean indicating whether the individual engages in risky behaviour (true) or not (false). The risky behaviour can be 
	 * anything from bindge drinking, drug abuse to smoking or extreme sports. We do not define it explicitly in the model 
	 * but we assume that it increases the risk of a health shock by a factor (parameter). 	 */
	protected boolean	risky_behaviour;
	protected int 		n_children=0;
	protected int 		aspiration_educ;
	protected String 	comment;
	
	
	
	// Social network
	protected Family family;
	public Family familyOriginal;
	protected Individual mother = null;
	protected Individual father = null;
	protected Individual partner = null;
	public HashMap<Individual,Double> socialnetwork; // = new HashMap<Individual,Double>();
	public HashMap<Individual,Double> socialnetworkCFAllIn; // = new HashMap<Individual,Double>();
	public HashMap<Individual,Double> socialnetworkCFNoOut; // = new HashMap<Individual,Double>();
	
	// Status variables
	protected Location location;
	public int dead =0;
	/**
	 * Adapts the life-status of an individual in function of his/her relationship status and the age
	 * 0: Pre-school child
	 * 1: Child
	 * 2: Young adult (ready for a mating)
	 * 3: In relationship
	 * 4: Widower
	 */
	public int life_status = 0;
	private boolean atschool=false;	
	protected boolean willingContinueSchool=true;
	public School school=null;
	
	public double salaryOfPeriod = 0.0;
	// Analysis variables
	/**
	 * // 0 no info <br>1 finished up to max <br>2 parental aspirations <br>3 individuals' choice <br> 4 Economic reasons <br> 5 No school available <br> 6 Family reason <br> 7 Too many failed grades
	 * <br>11 finished a grade
	 */
	public int reason_left_school = 0; 
	//public int test =0;

	/** Last health shock suffered by the individual */
		protected float healthShock=(float) 0.0; 
	/** Counterfactual health shock: assuming that health status was best possible */
		protected float healthShockCF;

	public double hce=0;

	// CAPABILITIES
	protected boolean capabFullRecoveryPossible;
	protected boolean capabDowngradeToPublic;
	protected int capabSNPossibleAdditions;
	protected int capabSNLostContacts;

	private double initialHealth;

	private int initialSNSize;

	

	
	/**
	 * Generate a new individual (for initialisation only) 
	 * @param female
	 * @param age
	 * @param IQ
	 * @param years_educ
	 * @param personality
	 */
	public Individual(boolean female, int age, float IQ, int years_educ, float personality){
		this.female = female;
		this.age 	= age;
		this.IQ 	= IQ;
		this.educ_years = years_educ;
		this.personality = personality;
		this.risky_behaviour = getRandomBoolean(0.5);
		this.health_status = 1;
		this.initialHealth=this.health_status;
		this.human_capital = this.educ_years * (IQ/100);
		socialnetwork = new HashMap<Individual,Double>();
		this.aspiration_educ = Math.max(6,Math.min(16,years_educ + RandomHelper.nextIntFromTo(0, 2))); // will be overridden for children during initialisation
		//this.income = 000; //this.getSalary(true); 
		
		this.ID = Model.counter_indiv;
		Model.counter_indiv++;
		
		
		//System.out.printf("-> a new individual has been created: female=%s;age=%s, IQ=%s, educ=%s\n",this.female,this.age,this.IQ,this.years_educ);
		
		
	
	}





	/**
	 * Creator of Individual based on procreation (only parental information required)
	 * @param mother
	 * @param father
	 */
	public Individual(Individual mother, Individual father) {
		this.mother = mother;
		this.father = father;
		this.family = mother.family;
		this.location=this.family.location;
		this.familyOriginal = this.family;
		Model.count_birth++;
		// Personal characteristics
		this.female = RandomHelper.nextDoubleFromTo(0, 1)>0.5;
		this.age 	= 0;
		this.IQ 	= genIQ(mother.IQ , father.IQ);
		this.healthShock = (float) 0.0;
		this.healthShockCF = (float) 0.0;
		this.educ_years = 0;
		this.human_capital = 0;
		double probability_riskyBehaviour = 0.25+(Agent.boolean2int(mother.risky_behaviour)+Agent.boolean2int(father.risky_behaviour))*0.25;
		this.risky_behaviour = (RandomHelper.nextDoubleFromTo(0,1)<probability_riskyBehaviour);  
		
		socialnetwork = new HashMap<Individual,Double>();
		socialnetworkCFAllIn = new HashMap<Individual,Double>();
		socialnetworkCFNoOut = new HashMap<Individual,Double>();
		double sigmaH = RunEnvironment.getInstance().getParameters().getDouble("sigmaH"); 

		if(sigmaH<0){
			this.health_status = 1;
		}
		else{
			this.health_status = (float) ((mother.health_status+father.health_status)/2+RandomHelper.createNormal(0, sigmaH).nextDouble());
			this.health_status = (float) Math.min(1,Math.max(0.1,this.health_status));  // ensure to be within the possible range. 
			
		}
		
		this.initialHealth=this.health_status;
		
		
		double sigmaPers = RunEnvironment.getInstance().getParameters().getDouble("sigmaPers"); 
		this.personality = (float) Math.min(1,Math.max(0,(mother.personality+father.personality)/2+RandomHelper.createNormal(0, sigmaPers ).nextDouble()));
		
		this.setAspirations();
		
		// ADD a certain proportion of the familiy social network to the child's social network. 
		Parameters params = RunEnvironment.getInstance().getParameters();
			double deltaInherit = params.getDouble("deltaInherit");
			
			
			if(deltaInherit>0.0){
				HashMap<Individual,Double> parentalSN = new HashMap<Individual,Double>();
				parentalSN.putAll(mother.socialnetwork); 
				parentalSN.putAll(father.socialnetwork); 
				
				
				// With the probability deltaInherit, each element is transmitted to the child
				for(HashMap.Entry<Individual,Double> e:parentalSN.entrySet()){
					if(RandomHelper.nextDoubleFromTo(0, 1)<deltaInherit){
						//System.out.println("Yes, I got a link from my parents");
						this.socialnetwork.put(e.getKey(),e.getValue());
					}
					/*else{
						System.out.println("Nope, this link wasn't given to me");
					}*/
				}
				
				
				this.socialnetworkCFAllIn = (HashMap<Individual, Double>) this.socialnetwork.clone();
				this.socialnetworkCFNoOut = (HashMap<Individual, Double>) this.socialnetwork.clone();
				
				//System.out.printf("!!SN: mo:%s, fa:%s, comb:%s, child:%s, childCFAllIn:%s, childCFNoOut:%s\n",mother.socialnetwork.size(),father.socialnetwork.size(),parentalSN.size(),this.socialnetwork.size(),this.socialnetworkCFAllIn.size(),this.socialnetworkCFNoOut.size());
				
			}
			
		this.initialSNSize = this.socialnetwork.size();
			
		
		this.ID = Model.counter_indiv;
		Model.counter_indiv++;
	}
	
	

	
	
	//Step: 96 Individual.stepAgePeople()
	@ScheduledMethod(start=1,interval=1, priority=96,shuffle=true) 
	public void stepAgePeople(){
		Parameters params = RunEnvironment.getInstance().getParameters();
		
		// Reset periodical values
		this.capabDowngradeToPublic=false;
		this.capabFullRecoveryPossible=true;
		this.comment="";
		
		// 0: get values
		//Location mylocation3 = Model.locations.get(2); //this.family.getLocation();
			
		// 1:  Agent get a year older and die if their health stock if too low
			
			this.age++;
			this.salaryOfPeriod = 0.0;
			this.hce=0.0;
			this.health_status	-=this.healthShock();
			if(this.checkIfDies()){	// old people die
				this.die(); 
			}
			
			
			if(this.school==null & this.atschool==true){
				String familyid = "NULL";
				if(this.family!=null){
					familyid = String.valueOf(this.family.ID);
				}
				System.out.printf("THIS IS A PROBLEMATIC CHILD (%s) [%s]\n",this.ID,familyid);
				
			}
			
			
			// ADD YEARS OF EDUCATION
			if(this.family!=null && this.atschool ){
				checkPassGrade();
			}
			
			
			// ADAPT THE LIFE STATUS
			checkLifeStatus();
		
			
		
			
		// 3: Partner search
			
			Integer gamma = params.getInteger("gamma");
			if(this.dead==0 && this.partner==null && this.age>=gamma){ 
				Model.count_mating_attempts++;
				//System.out.printf("=== START MATING PROCESS OF INDIVIDUAL %s ===\n",this.hashCode());
				Vector<Individual>  candidates = new Vector<Individual>();
				double prob = 0.0;
				for(Individual c:this.socialnetwork.keySet()){ 
					if(c.partner==null & this.female!=c.female & c.age>=gamma){
						candidates.add(c);
						prob += 1-Math.abs(c.personality-this.personality);
						
					}
				}
				
				@SuppressWarnings("unchecked")
				Context<Object> mycontext = Model.context; 
				
				
				if(candidates.size()>0){
					double thetaM = params.getDouble("thetaM"); 
					double x = RandomHelper.nextDoubleFromTo(0.0, prob/thetaM);
					if(x<=prob){ // => we have a match, let's see who it is
						double prob2=0.0;
						Iterator<Individual> iter = candidates.iterator();
						
						while(iter.hasNext()){
							Individual thiscandidate=iter.next();
							if(prob2<x){
							
							prob2 +=1-Math.abs(thiscandidate.personality-this.personality);
							if(prob2>=x){
								this.partner 			= thiscandidate;
								thiscandidate.partner 	= this;
								Model.count_mating_success++;
								if(this.female==true){
									Location famlocation = this.family.location;
									double bequest 	= this.leaveFamily(false);
									bequest 		+=thiscandidate.leaveFamily(false);
									
									Family newfamily = new Family(famlocation,this,thiscandidate,bequest);
									
									mycontext.add(newfamily);
									
									// move on the grid
									float xcoord = (float) Math.min(49.999,Math.max(0,newfamily.location.xcoord + RandomHelper.createNormal(0, 1).nextDouble()));
									float ycoord = (float) Math.min(49.999,Math.max(0,newfamily.location.ycoord + RandomHelper.createNormal(0, 1).nextDouble()));
									
									this.move(xcoord,ycoord);
									newfamily.move(xcoord,ycoord);
									//thiscandidate.move(xcoord, ycoord);
									
									
								}
								else{
									Location famlocation = this.family.location;
									double bequest = 0.0;
									bequest += this.leaveFamily(false);
									bequest += 		thiscandidate.leaveFamily(false);
									Family newfamily = new Family(famlocation,thiscandidate,this,bequest); 
									mycontext.add(newfamily);
									
									// move on the grid
									float xcoord = (float) Math.min(49.99999,Math.max(0,newfamily.location.xcoord + RandomHelper.createNormal(0, 1).nextDouble()));
									float ycoord = (float) Math.min(49.99999,Math.max(0,newfamily.location.ycoord + RandomHelper.createNormal(0, 1).nextDouble()));
									//this.move(xcoord,ycoord);
									newfamily.move(xcoord,ycoord);
									
								}
								
								//System.out.printf("A new family has been created: %s",newfamily.toString());
								
								
								
								} // end prob2>=x
							} // end prob2<x
						
					} // end loop through candidates
				}
				}
				//System.out.printf("Individual %s has %s candidates to partnership (SN-size:%s), SUM=%s\n",this.toString(),candidates.size(),this.socialnetwork.size(),prob);
				/*if(candidates.size()==0){
						System.out.println("ME:");
						this.describe();
						System.out.println("SOCIAL NETWORK:");
						for(Individual i:this.socialnetwork){
							if(i.female!=this.female){
								i.describe();
							}
						}
				}*/
				if(this.partner!=null){
					//System.out.printf("\t Mating successful!! /n");
				}
				
				//System.out.printf("=== END OF MATING PROCESS OF INDIVIDUAL %s ===\n",this.hashCode());
			}
	}
	
	
	/**
	 * Method to leave a family due to death or mating. In both cases the system checks whether
	 * @param death TRUE if the reason for leaving is death, FALSE otherwise
	 * @return only for death==FALSE: return the share of the bequest in case this is already a family of pure siblings
	 */
	private double leaveFamily(boolean death) {
		//System.out.printf("INDIV leaving: %s\n",this.ID);
		double result = 0.0;
		if(death==false){
			
			// Leaving family due to new partnership: 2 possibilitites: if it was a single, then (s)he takes the savings with her, otherwise without bequest
			
			if(this.familyOriginal!=this.family && this.family.getFamilySize()==1){
				this.family.clearFamilyMembers();
				result = this.family.savings;
				Model.context.remove(this.family);
				
			}
			else{
				result = 0.0;
			}
			
		}	
		else{	// death
			
			result = 0.0;
			
		}
		
		// Ensure that this is no longer pointed to
		if(this.family.father!=null && this.family.father==this){
				this.family.father=null;
		}
		if(this.family.mother!=null && this.family.mother==this){
				this.family.mother=null;
		}
		if(this.family.children.contains(this)){
			this.family.children.remove(this);
		}
		this.family=null;
		
		
		return result;
		
		
		
		
	}
	
	/*
	 @ScheduledMethod(start=1,interval=1,priority=97,shuffle=false)
	 public void stepCheckSN(){
		if(this.socialnetwork.size()!=this.socialnetworkCFAllIn.size() | this.socialnetwork.size()!=this.socialnetworkCFNoOut.size()){
			this.describeMySocialNetwork();
		}
	}
	*/

	/**
	 * Prints summary information about the social network of the individual (to the console only)
	 */
	private void describeMySocialNetwork() {
		System.out.printf("ID:%s\t SNsize:%s\t SNsizeCFAllIn:%s\t SNsizeCFNoOut:%s\n", this.ID,this.socialnetwork.size(),this.socialnetworkCFAllIn.size(),this.socialnetworkCFNoOut.size());
		
	}


	//Step: 92 Individual.stepUpdateSN1()
	@ScheduledMethod(start=1,interval=1, priority=92,shuffle=true)
	public void stepUpdateSN1(){
		
		/*
		 * Loop over all possible candidates: 
		 * - if match, then add to actual social network (symmetrically)
		 * - in any case, add it to the AllIn social network (symmetrically)
		 * 
		 */

		// Reset counting variables
		this.capabSNPossibleAdditions	= 0;
		this.capabSNLostContacts		= 0;
		
		
		// Clean social network in case the partner died
		Context<Object> mycontext = ContextUtils.getContext(this);
		cleanSNFromDead(this.socialnetwork,mycontext);
		cleanSNFromDead(this.socialnetworkCFAllIn,mycontext);
		cleanSNFromDead(this.socialnetworkCFNoOut,mycontext);

		double thetaSN  = RunEnvironment.getInstance().getParameters().getDouble("thetaSN"); 



		if(this.school!=null){ // Individual is still at school
			for(Individual partner:this.school.students){ // loop over all possible candidates and current members
				
				
				
				// ACTUAL SOCIAL-NETWORK
				if(!this.socialnetwork.containsKey(partner)){ // This is a candidate, as he/she not yet in SN
					this.capabSNPossibleAdditions++; // Here we count each possible candidate
					
					if(partner!=this && RandomHelper.nextDoubleFromTo(0, 1)<thetaSN*(1-Math.abs(this.personality-partner.personality))){
						this.socialnetwork.put(partner,0.0);	 	//add the partner to my social network
						partner.socialnetwork.put(this, 0.0); 		// add me to the social network of the partner
						
						this.socialnetworkCFNoOut.put(partner, 0.0);
						partner.socialnetworkCFNoOut.put(this, 0.0);
					}
					
					// Add the link anyway to the AllIn network
					this.socialnetworkCFAllIn.put(partner, 0.0);
					partner.socialnetworkCFAllIn.put(this, 0.0);
					
				} // end: not yet in SN
				
			} // end: loop over school mates
		} //end: if at school
	}
	



	//Step: 91 Indivudal.stepUpdateSN2
	@ScheduledMethod(start=1,interval=1, priority=91,shuffle=true)
	public void stepUpdateSN2(){
		
		
		this.capabSNLostContacts		= 0;
		
		
		Vector<Individual> currentFriends = new Vector<Individual>();
		if(this.school!=null){
			for(Individual i:this.school.students){
				//if(i.educ_years==this.educ_years){  // limit to grade-mates only!
						currentFriends.add(i);
				//}
			}
		}

		this.capabSNLostContacts = adaptSNINtensity(this.socialnetwork,currentFriends,true);
		adaptSNINtensity(this.socialnetworkCFAllIn,currentFriends,true);
		adaptSNINtensity(this.socialnetworkCFNoOut,currentFriends,false);
		
		
		// ADAPT THE risky behaviour of the agent, based on the social network
		double probabilityRiskyBehaviour = 0;
		for(Individual i:this.socialnetwork.keySet()){ 
			probabilityRiskyBehaviour += boolean2int(i.risky_behaviour);
		}
		// Obtain the parameter for the sensitivity to the social network
		Parameters params = RunEnvironment.getInstance().getParameters();
		double phiRB = params.getDouble("phiRB"); 
		// Compute the average risky behaviour in the social network
		probabilityRiskyBehaviour = phiRB*(probabilityRiskyBehaviour / this.socialnetwork.size())+ (1-phiRB)*boolean2int(this.risky_behaviour);
		boolean backupRB = this.risky_behaviour;

		// Define the actual risky behaviour as a random functing using the probability.  
		this.risky_behaviour = (RandomHelper.nextDoubleFromTo(0, 1)<probabilityRiskyBehaviour);
		
		
	}	// end stepUpdateSN
	
	
	
	/** 
	 * Updates the intensity indicators of each social tie and returns the number of lost ties. 
	 * @param SN the social network (HashMap) that should be updated
	 * @param students (list of students with which the person is in the same school)
	 * @return Number of lost ties
	 */
	private int adaptSNINtensity(HashMap<Individual, Double> SN, Vector<Individual> students, boolean allowDecrease) {
		
		int counter = 0;
		// Load parameters
				double deltaSnPlus  	= RunEnvironment.getInstance().getParameters().getDouble("deltaSnPlus");
				double deltaSnMinus 	= RunEnvironment.getInstance().getParameters().getDouble("deltaSnMinus");
				double deltaSnThreshold = RunEnvironment.getInstance().getParameters().getDouble("deltaSnT"); 

				
				
		Iterator<Entry<Individual, Double>> iter = SN.entrySet().iterator();
		while(iter.hasNext()){
			Individual indiv = (Individual) iter.next().getKey();
			if(students.contains(indiv)){ // still together => increase intensity
				SN.put(indiv, SN.get(indiv)+deltaSnPlus);
			}
			else{ // no longer together, decrease intensity if below threshold
				if(allowDecrease && SN.get(indiv)<deltaSnThreshold){
					SN.put(indiv,  SN.get(indiv)-deltaSnMinus);
				}
				
				// Drop the link if the link intensity is below 0.0
				if(SN.get(indiv)<=0.0){
					iter.remove();
					counter++;
				}
			}
		}
		return counter;
	}


	/**
	 * Simulates whether the child passes the grade of not. The corresponding values are automatically adapted. In case of passing and finishing a level, the child is 
	 * taken out of the school. 
	 */
	private void checkPassGrade() {
		
		
		if(this.school==null){
			System.out.printf("I HAVE A NULL-POINTER FOR THE SCHOOL OF INDIVIDUAL %s\n",this.ID );
		}
			
		
		
		
		
		// Get the best school for they counterfactual education level (can be higher than the actual level)
		School bestCFSchool = this.location.getBestSchoolByLevel(this.educ_yearsCF);
		
		//|System.out.printf("My school quality=%s\t Best CF school quality=%s\n",this.school.quality,bestCFSchool.quality);
			
		
		// Human Capital accumulation (true and counter-factual)
		double randomElementHC = RandomHelper.createNormal(0, 0.1).nextDouble();
		double addHC = this.school.quality * this.IQ/100 * this.health_status + randomElementHC;
		double addHC_CF=0;
		if(bestCFSchool!=null){
			addHC_CF = bestCFSchool.quality * this.IQ/100 * this.health_status + randomElementHC;
				// Check if in the counterfactual world the student would have passed
				if(this.educ_yearsCF<16 && this.human_capitalCF + addHC_CF  >= bestCFSchool.getDelta()*((float)this.educ_yearsCF+1)){ 
					this.educ_yearsCF++;
					this.human_capitalCF+=addHC_CF;
				}
				else{
					this.human_capitalCF += addHC_CF; // The additional HC would have been added anyway
				}
		}
		
		
		
		
		// True schooling
		if(this.human_capital + addHC  >= this.school.getDelta()*((float)this.educ_years+1)){ 
			// THE students passes the grade
			this.educ_years++;
			this.human_capital +=addHC;
			
			/*double savings=-1;
			if(this.family!=null){	
				savings = this.family.savings;
			}*/
			//System.out.printf("Individual %s just passed a grade (he/she has now %s years of educ; family savings: %s) [test=%s)\n", this.toString(),this.years_educ,savings,this.test);
			Model.count_passed++;
			if(this.educ_years==6 | this.educ_years==9 | this.educ_years==12 | this.educ_years==16){
				this.school.quitSchool(this,-1);
				this.school=null;
				this.atschool=false; 
				this.reason_left_school = 11;
				this.failedGradesLevel = 0; // reset as the level ends here
				
				// CHECK IF THE CHILD STILL HAS ASPIRATIONS
				if(this.family.checkIfWillingToEnroll(this)==false){
					this.willingContinueSchool=false;
					this.comment+="Dropoutreason must be 2 or 3 (it is="+this.reason_left_school+"|";
					
					
				}
				else {
					this.willingContinueSchool = true;
					this.comment+="Aims at continuing...";
				}
				
				if(this.educ_years==16){
					this.atschool=false;		// Finished education (no more schooling available in our model!)
					this.reason_left_school = 1; // Up to max
				}
			}
			
			
			
		
			
			
		}
		else{
			this.failedgrades++;		// Overall failed grades
			this.failedGradesLevel++;	// Number of failed grades within this level
			
			// CHECK IF NOT TOO MANY TIMES REPEATED A GRADE
						Parameters params = RunEnvironment.getInstance().getParameters();
			int maxRepeatedGrades = params.getInteger("alphaUp");
			if(this.educ_years<6){	//primary
				maxRepeatedGrades = params.getInteger("alphaPrim");
			}
			if(this.failedGradesLevel> maxRepeatedGrades){
				this.school.quitSchool(this, 7);
				this.atschool=false;
				//System.out.printf("Individual %s drops out of school due to too many repeated grades (rep grades level: %s; educ: %s)\n",this.ID,this.failedGradesLevel,this.educ_years);
				//RunEnvironment.getInstance().pauseRun();
			}
			
			
		

			this.human_capital += addHC;
			Model.count_failed++;
			//System.out.printf("Individual %s just failed a grade\n", this.toString());
		}
		
		
		//System.out.printf("Summary of checkPassGrade for ID=%s\n\t Educ: true=%s\t CF=%s\n\t HC true=%s\t CF=%s\n",this.ID,this.educ_years,this.educ_yearsCF,this.human_capital,this.human_capitalCF);
		
	} // end: checkPassGrade()


	/**
	 * Adapts the life-status of an individual in function of his/her relationship status and the age
	 * 1: Child
	 * 2: Young adult (ready for a mating)
	 * 3: In relationship
	 * 4: Widower
	 */
	private void checkLifeStatus() {
		if(this.age<6){
			this.life_status=0;
		}
		else if(this.age<15){
			this.life_status=1;
		}
		else if(this.age>=15 & this.partner==null & this.life_status<=2){
			this.life_status=2;
		}
		else if(this.age>15 & this.partner!=null){
			this.life_status=3;
		}
		else if(this.age>=15 & this.partner==null & this.life_status>2){
			this.life_status=4;
		}
		
		
	}


	/**
	 * Checks if the partners in the social network are still alive (=present in the context). If they are dead, they are removed. 
	 * @param SN
	 * @param mycontext
	 */
	private void cleanSNFromDead(HashMap<Individual, Double> SN, Context<Object> mycontext) {
		
		//int before = SN.size();
		Iterator<Entry<Individual, Double>> iter = SN.entrySet().iterator();
		while(iter.hasNext()){
			Individual partner = iter.next().getKey();
			if(!mycontext.contains(partner)){
				iter.remove();
				//System.out.println("I just lost a fiend...");
			}
		}
		
		//System.out.printf("=> MY SN before: %s and now %s\n",before,SN.size());
		
	}


	/**
	 * Generates the IQ of the CHILD based on parental values and a random term
	 * @param IQ of the mother
	 * @param IQ of the father
	 * @return IQ of the child
	 */
	private float genIQ(float iq_mother, float iq_father) {
		float IQ = (float) (51.8772+0.2059*iq_father + 0.2857*iq_mother + RandomHelper.createNormal(0, 13.53).nextDouble());
		return IQ;
	}
	
	
	/**
	 * Add the two individuals to the social network of each other (only used for initialisation). 
	 * @param partner Which is the partner to be added
	 * 
	 **/
	public void addSocialTie(Individual partner){
		// Load parameters
		double deltaSnPlus   	= RunEnvironment.getInstance().getParameters().getDouble("deltaSnPlus");
		double deltaSnThreshold = RunEnvironment.getInstance().getParameters().getDouble("deltaSnT"); 
		
		double intensity = deltaSnThreshold + RandomHelper.nextIntFromTo(0,4)*deltaSnPlus;

		if(this.socialnetwork.containsKey(partner)==false){ 
			this.socialnetwork.put(partner,intensity);
		}
		if(partner.socialnetwork.containsKey(this)==false){ 
			partner.socialnetwork.put(this,intensity);
		}
	}
	
	/**
	 * Generates a health shock which is parameterised through the model parameters. 'HS:p' is the probability of any 
	 * health shock and 'HS:lambda' is the parameter of the exponential function. 
	 * @return float Health shock
	 */
	public  float healthShock(){
		Parameters params = RunEnvironment.getInstance().getParameters();
		
		double lambda = 0.1 + 1/ (double)((double)age/100.0); 
		double phiRF	= params.getDouble("phiRF"); 
		double p = (0.2172885 -0.0020591 * this.age + 0.0000633 *Math.pow(this.age, 2))+(1-health_status) ;	// Currently based on  04_ProbabilityOfHealthProblems_BY_age
		
		double pCF = p - (1-health_status); // here we assume perfect health status (=perfect recovery in the last period)
		
		if(this.risky_behaviour){
			p = phiRF*p;
			pCF = phiRF*pCF;
		}
		
		//System.out.printf("Individual of age %s, risky behaviour=%s    => P=%s\n",this.age,this.risky_behaviour,p);
		
		float result = (float) 0.000;
		float resultCF = (float) 0.0;
		double randomNumber = RandomHelper.nextDoubleFromTo(0, 1);
		double size = RandomHelper.createExponential(lambda).nextDouble();
		
		// Simulate the actual health shock
		if(randomNumber<=p){
			result = (float)size; 
		}
		
		//Simulate the counter-factural health shock
		if(randomNumber<=pCF){
			resultCF = (float)size; 
		}
		this.healthShock	=result;
		this.healthShockCF 	=resultCF;
		
		
		//System.out.printf("HealthShock=%s\n",this.healthShock);
		return result;
	}
	
	/**
	 * Return the salary that can be expected based on the characteristics. The option allows to turn on/off the random part.
	 * @param stochastic if TRUE then the random term is added, if FALSE it's not added
	 * @return
	 */
	public float getSalary(boolean stochastic){
		
		// note: IF THE INDIVIDUAL HAS NO LOCATION ANYMORE, IT MIGHTBE DEAD!!
		
		int estrato 		= this.family.location.type-1;
		float beta_educ 	= Agent.mincer[Agent.educYearToLevel(this.educ_years)][estrato];
		float beta_exp 		= Agent.mincer[8][estrato];
		float beta_exp2 	= Agent.mincer[9][estrato];
		float beta_iq 		= Agent.mincer[10][estrato];
		float beta_cons 	= Agent.mincer[11][estrato];
		float sd 			= Agent.mincer[12][estrato];
		Parameters params = RunEnvironment.getInstance().getParameters();
			double thetaInc 	= params.getDouble("thetaInc"); 
			double thetaIncvar 	= params.getDouble("thetaIncvar");
		double error = 0;
		if(stochastic){
			error = RandomHelper.createNormal(0, thetaIncvar*sd).nextDouble();
		}
		
		double exp 	= Math.min(0, age - this.educ_years-6);
		double exp2 = Math.pow(exp,2);
		double xi = params.getDouble("xi");
		
		float salary = Math.max(0, (float) ((float) Math.pow(this.health_status,xi) * thetaInc * Math.exp(beta_cons + beta_educ + beta_exp*exp + beta_exp2*exp2+ beta_iq * this.IQ + error)));
		
		
		if(salary == Double.NaN){
			System.out.printf("I am getting a Double.NaN salary (in method Individual.getSalary())\n");
			this.describe();
			System.exit(0);
		}
		
			this.salaryOfPeriod = salary;
			return salary;
		
		
		
		
		
	}
	/**
	 * Returns a boolean indicating whether or not the woman has a child this period. The probability is based on the education level 
	 * and the age. 
	 * @return boolean hasChild
	 */
	protected boolean drawChild(){
		//System.out.printf("Does this %s years old woman with %s years of educ get a child?\n",this.age,this.years_educ);
		int educcat = educYearToLevel(this.educ_years);
		float probability = (float) 0.0000000;
		if(this.age<=45){
			probability = Agent.prob_child[this.age][educcat];
			//System.out.printf("\t The probability is: %s%n", probability);
		}
		boolean result = false;
		if(RandomHelper.nextDoubleFromTo(0, 1)<Model.fertility_inflator*probability){
			result = true;
		}
		//System.out.printf("\t The probability is: %s \tresult=%s%n", probability,result);
		return result;
	}
	
	/**
	 * Get's the average value in the social network of the individual. The parameters refers to the concept that should be computed: <br>
	 * 1: Age<br>
	 * 2: IQ<br>
	 * 3: Years of education<br>
	 * 4: Personality<br>
	 * 5: Risky behaviour<br>
	 * 6: Female
	 * @param integer 
	 * @return double average
	 */
	protected double getAvgFromSN(int stat){
		
		double sum = 0;
		int N = 0;
		
		for(Individual partner:this.socialnetwork.keySet()){ 
			switch(stat){
			case 1: sum += partner.age; break;
			case 2: sum	+=partner.IQ; break;
			case 3: sum	+=partner.educ_years ; break;
			case 4: sum	+=partner.personality; break;
			case 5: sum	+=boolean2int(partner.risky_behaviour); break;
			case 6: sum	+=boolean2int(partner.female); break;
			default: return -99999;
			}
					
					
			N++;
		}
		
		double average = -1.0; // default value if no social network
		if(N>0){
			average = sum / N;
		}
		return average;
	
	}


	/** 
	 * Removes the  individual and if necessary also the family (if this was the last member)
	 */
	private void die(){
		//this method removes the agent from the context. if it is the last of the family, then the family is eliminated as well
		this.dead  = 1;
		Model.count_death++;
		@SuppressWarnings("unchecked")
		Context<Object> mycontext = ContextUtils.getContext(this);
			boolean removeFamily=false;
		
			if(family!=null){
			
			Family myfamily=this.family;
			double savings = myfamily.savings;
			
			
			if(this==myfamily.father){
				if(myfamily.mother==null){ // last parent dying => dissolve the family
					//System.out.printf("Father is dying last of parents, we have to split the family (id=%s)",myfamily.ID);
					//myfamily.describe();
					myfamily.splitFamily();
					myfamily.bequest();
					removeFamily=true;
					
				}
				
				myfamily.father=null;
			}
						
			if(this==myfamily.mother){ // last parent dying => dissolve the family
				if(myfamily.father==null){
					//System.out.printf("Mother is dying last of parents, we have to split the family (id=%s)",myfamily.ID);
					//myfamily.describe();
					//Bequest!
					myfamily.splitFamily();	
					myfamily.bequest();
					removeFamily=true;
				}
				myfamily.mother=null;
			}
			
			
			
		
			// CHECK IF POINTED TO BY THE ORIGINAL FAMILY: IF YES, DELETE IT!
			if(this.familyOriginal!=null && this.familyOriginal.children.contains(this)){
				this.familyOriginal.children.remove(this);
			}
			
			
			
			// Clear partnership
			if(this.partner!=null){
				this.partner.partner=null;
				this.partner=null;
			}
			
			
			
			// If it is the child of the current family, then remove it from the vector
			myfamily.children.remove(this);
			
			
			
			
			
			// Clear the social network of the individual (links to me will be dropped in stepUpdateSN1)
			this.socialnetwork.clear();
			this.socialnetworkCFNoOut.clear(); 
			this.socialnetworkCFAllIn.clear(); 
		
			
			
			if(removeFamily==true || (myfamily.father==null && myfamily.mother==null && myfamily.children.size()==0)){
				mycontext.remove(myfamily);
			}
			
			
		
			
			
			
			}
			
			mycontext.remove(this);
			
			
			
			
	}



			/** 
			 * Determines whether the individual dies or not
			 * @return
			 */
			private boolean checkIfDies(){
				if(this.health_status<0 || this.age>95){
					//System.out.printf("I die (Health stock: %s)\n",this.health_status);
				
					return true;
									}
				else{
					//System.out.printf("I don't die yet!(Health stock: %s)\n",this.health_status);
					return false;
				}
			}
	
	/**		
	 * Returns the expected years to the next graduation. If consdier_repeat==true then the normal time is divided by the average
	 * number of grades per year (1 if never failed a grade, below 1 if failed a grade in the past);
	 * @param consider_repeat
	 * @return
	 */
	public double timeToGraduation(boolean consider_repeat){
		
		// CHECK IF REPETITION PROBABILITY SHOULD BE CONSIDERED
		double ratio = 1;
		if(consider_repeat==true && this.educ_years>0){
			ratio  = (double)this.educ_years / ((double) this.educ_years+(double)this.failedgrades);
		}
		
		double result = -1;
			
		if(this.atschool){
			if(this.educ_years<=6){
				result = (6-this.educ_years)/ratio;
			}
			else if(this.educ_years>=6 & this.educ_years<9){
				result = (9-this.educ_years)/ratio;
			}
			else if(this.educ_years>=9 & this.educ_years<12){
				result = (12-this.educ_years)/ratio;
			}
			else if(this.educ_years>=12 & this.educ_years<=16){
				result = (16-this.educ_years)/ratio;
			}
		}
		else{
			result = -1;
		}
		
		//System.out.printf("Time to graduation (years=%s; failed=%s) => %s years",this.years_educ,this.failedgrades,result);
		return result;
		
		
	}
	/** 
	 * Returns 1 if the individual is supposed to be dead, and zero otherwise
	 * @return
	 */
	public int isDead(){
		return this.dead;
	}
	
	/**
	 * Returns the age of the agent
	 * @return
	 */
	public int getAge(){
		return this.age;
	}
	
	/** 
	 * Returns 1 for each individual (for counting purpose)
	 * @return
	 */
	public int isIndividual(){
		return 1;
	}
	
	/**
	 * Returns the health stock of the individual 
	 * @return
	 */
	public float getHealthStock(){
		return this.health_status;
	}

	/**
	 * Returns the life status<br>
	 * 1 Child <br>
	 * 2 Single <br>
	 * 3 Married <br>
	 * 4 Widowed <br> 
	 * @return
	 */
	public int getLifeStatus(){
		return this.life_status;
	}
	
	/**
	 * Returns the ration of (human capital) / (years of education). It should always be between zero and 1
	 * @return
	 */
	 
	public double getHC_educ_ratio(){
		return (double) this.human_capital / (double)this.educ_years;
	}
	
	/**
	 * Returns the size of the social network
	 * @return
	 */
	public int getSNsize(){
		return this.socialnetwork.size(); 
	}
	
	/**
	 * Returns the size of the counter-factual social network 'No-Out'
	 * @return
	 */
	public int getSNsizeNoOut(){
		return this.socialnetworkCFNoOut.size(); 
	}
	
	/**
	 * Returns the size of the counter-factual social network 'All-In'
	 * @return
	 */
	public int getSNsizeAllIn(){
		return this.socialnetworkCFAllIn.size(); 
	}
	
	
	
	/**
	 * Returns the size of any social network (in the argument)
	 * @param network
	 * @return
	 */
	public int getSNsize(HashMap<Individual, Double> network){
		return network.size(); 
	}
	
	
	
	/**
	 * Return 1 if the individual is at school and 0 otherwise
	 * @return binary indicator for enrollment
	 */
	public int isAtSchool(){
		if(this.atschool){
			return 1;
		}
		else{
			return 0;
		}
	}

	/**
	 * Return the code for the dropout reason: <br>-1 still at school<br> 0 no info (possibily initial indiviuals)<br>1 finished up to max <br>2 parental aspirations <br>3 individuals' choice 
	 * <br> 4 Economic reasons <br> No school available
	 * @return code
	 */
	public int getReasonQuitSchool(){
		if(this.atschool==true){
			return -1;
		}
		else{
			return this.reason_left_school;
		}
	}
	
	
	
	public void describe() {
		System.out.printf("INDIVIDUAL-%s:",this.ID);
		System.out.printf("Female=%s",female);
		System.out.printf("Age=%s,",age);
		System.out.printf("IQ=%s,",IQ);
		System.out.printf("Educ=%s,",educ_years);
		System.out.printf("HS=%s,",health_status);
		System.out.printf("Inc=%s,",income);
		System.out.printf("Personality=%s,",personality);
		System.out.printf("Risky=%s,",risky_behaviour);
		System.out.printf("SNsize=%s,",socialnetwork.size()); 
		System.out.printf("ReasonQuitSchol=%s,",this.reason_left_school);
		System.out.printf("Single=%s",this.isSingle());
		System.out.printf("AtSchool=%s",this.atschool);
		System.out.printf("FamilyID:%s\n",this.family.ID);

					
				
	}

	/**
	 * Returns a dummy taking the value of 1 for singles (no partner) and 0 otherwise. 
	 * @return
	 */
	private int isSingle() {
		if(this.partner==null){
			return 1;
		}
		else{
			return 0;
		}
	}


	/**
	 * Returns the hash code of the family of the individual. In case no family is there, -9999 is returned. 
	 * @return
	 */
	public int getFamID() {
		if(this.family!=null){
			return this.family.ID;
		}
		else{
			return -9999;
		}
		
	}

	
	public double getTreatment(Hospital hospital, double investment) {
		return hospital.treat(investment);
				
	}


	/**
	 * Sets the aspirations in education of the child (based on parental aspirations)
	 */
	public void setAspirations() {
		double result = RandomHelper.createNormal(0, 2).nextDouble();
		
		result += getParentalAspiration();
		this.aspiration_educ = Math.min(16, Math.max(0,(int) Math.round(result)));
		
		
		
		//System.out.printf("=> CHILD = %s%n",this.aspiration_educ);
	}

	/**
	 * Computes the average aspirations of the parents and single aspirations if monoparental. 0.0 if no parents. 
	 * @return
	 */
	public double getParentalAspiration() {
		double result = 0.0;
		if(this.mother!=null && this.father!=null){
			//System.out.printf("Aspiration father=%s, mother=%s \t",father.aspiration_educ,mother.aspiration_educ);
			result = (double)(this.mother.aspiration_educ+this.father.aspiration_educ)/2;
			}
		else if(this.mother!=null){
			result = this.mother.aspiration_educ;
			//System.out.printf("Aspiration father=n/a, mother=%s \t",mother.aspiration_educ);

		}
		else if(this.father!=null){
			result =this.father.aspiration_educ;
			//System.out.printf("Aspiration father=%s, mother=n/a \t",father.aspiration_educ);
		}
		else{
			//System.out.printf("Aspiration father=n/a, mother=n/a\t");

		}
		return result;
	}

	/**
	 * Returns 1 for women and 0 for men
	 * @return
	 */
	public int isFemale(){
		if(female){
			return 1;
		}
		else{
			return 0;
		}
	}

	/** 
	 * Returns a string indicating the role of the individual: father (F), mother (M) or child (C). 
	 * @return
	 */
	public String getRole() {
		if(this.family.father!=null && this.family.father==this){
			if(this.life_status<3 & this.family.children.size()==0){
				return "S";
			}
			else{
				return "F";
			}
		}
		else if(this.family.mother!=null && this.family.mother==this){
			if(this.life_status<3 & this.family.children.size()==0){
				return "S";
			}
			else{
				return "M";
			}
		}
		else if (this.family.children.contains(this)){
			return "C";
		}
		else{
			return "U";
		}
	}
	
	/**
	 * Returns the years of schooling of those who ALREADY finished school and -5 for those still at school or not yet at school. 
	 * @return
	 */
	public int getYearsEduc(){
		if(this.age>6 && this.atschool==false && this.school==null){
			return this.educ_years;
		}
		else{
			return -5;
		}
	}


	/**
	 * Return 1 if individual.school!=null and 0 otherwise
	 * @return
	 */
	public int hasSchool() {
		if(this.school==null){
			return 0;
		}
		else{
			return 1;
		}
	}

	/**
	 * Returns the aspiration level of the individual. Aspiration is measured in years of education the individual is aiming at achieving. 
	 * @return
	 */
	public int getAspiration(){
		return this.aspiration_educ;
	}

	/**
	 * Returns a boolean taking the value of TRUE if currently enrolled and FALSE otherwise. 
	 * Note that upon level completion, the value is set to FALSE and then reset to TRUE in case of continuing. Thus, it is not 
	 * an indicator if the child has finished education.
	 * @return
	 */
	public boolean atSchool(){
		return this.atschool;
	}
	
	/**
	 * Sets the value of the boolean atSchool. Used for other classes to change this. 
	 * @param value
	 */
	public void setAtSchool(boolean value){
		this.atschool = value;
	}

	/**
	 * Returns an integer indicating what type of school the individual attends<br>
	 * 1 Private school<br>
	 * 0 Public school<br>
	 * -1 No school
	 * @return type of school
	 */
	public int privateSchool(){
		if(this.hasSchool()==1){
			if(this.school.privateschool){
				return 1;
			}
			else{
				return 0;
			}
		}
		else{
			return -1;
		}
	}
	
	/***
	 * Computes and returns the average wage level and average education level in the social network. Only positive salaries are considered. Only individual no longer willing to go to school are considered. 
	 * The method return an array of size two, with the first element being the average wage and the second the average education. 
	 * @return double[] array[avgSalary,avgEducation]
	 */
	public double[] getSNStats(){
		double[] result = {-1,-1};
		int 	n_wage=0, n_educ=0;
		double 	s_wage=0, s_educ=0;
		
		for(Individual i:this.socialnetwork.keySet()){ 
			if(! i.willingContinueSchool){
				n_educ++;
				s_educ+=i.educ_years;
			}
			
			if(i.salaryOfPeriod!=0.0){
				n_wage++;
				s_wage+=i.salaryOfPeriod;
			}
		}
		// Compute the wage average if there is data (keep -1 otherwise)
		if(n_wage>0){
			result[0] = s_wage/(double)n_wage;
		}
		
		
		// Compute the education average if there is data (keep -1 otherwise)
		if(n_educ>0){
			result[1] = s_educ / (double) n_educ;
		
		}
		return result;
		
	}

	/**
	 * Returns the number of individuals in the social network that have at least the specified number of years of education
	 * @param minYears thershold level of years of education
	 * @return number of people with minYears of education or more
	 */
	public int getSNEducAtLeast(int minYears) {
		int counter = 0;
		for(Individual i:this.socialnetwork.keySet()){ 
			if(i.educ_years>=minYears){
				counter++;
			}
		}
		return counter;
	}

	/**
	 * Returns the boolean capDowngradeToPublic as integer (dummy)
	 * @return
	 */
	public int getCapDowngradeToPublic(){
		return boolean2int(this.capabDowngradeToPublic);
	}
	
	/**
	 * Returns the boolean capFullRecoveryPossible as integer (dummy)
	 * @return
	 */
	public int getCapFullRecoveryPossible(){
		return boolean2int(this.capabFullRecoveryPossible);
	}
	
	
	public int getSchoolSize(){
		if(this.school!=null){
			return this.school.students.size();
		}
		else{
			return -1;
		}
	}


	/**
	 * Generates a String with tab-separated data for the individual
	 * @return
	 */
	public String getDataForSEMExort() {
		
		String output = "";
		
		output	+=	Integer.toString(this.ID)+"\t";
		output	+=  Integer.toString(this.age)+"\t";
		output 	+=	Integer.toString(this.location.getNumberOfSchools(1))+"\t";
		output 	+=	Integer.toString(this.location.getNumberOfSchools(2))+"\t";
		output 	+=	Integer.toString(this.location.getNumberOfSchools(3))+"\t";
		output 	+=	Integer.toString(this.location.getNumberOfSchools(4))+"\t";
		output 	+= 	String.format("%.2f",this.family.savings)+"\t";
		output 	+=  String.format("%.2f",this.family.income)+"\t";
		output  +=  Integer.toString(this.family.getFamilySize())+"\t";
		output 	+=  Integer.toString(this.family.children.size())+"\t";
		output 	+=  Integer.toString(Agent.boolean2int(this.female))+"\t";		
		output 	+=  Integer.toString(this.privateSchool())+"\t";	
		output 	+=  Integer.toString(this.failedgrades)+"\t";	
		output 	+=  Integer.toString(this.educ_years)+"\t";	
		output 	+=  String.format("%.2f", this.human_capital)+"\t";
		output  +=  String.format("%.4f", this.IQ)+"\t";
		output  += 	Integer.toString(this.getFeduc())+"\t";
		output  += 	Integer.toString(this.getMeduc())+"\t";
		output 	+=  Integer.toString(this.reason_left_school)+"\t";
		output 	+=  Double.toString(this.getSchoolQuality())+"\t";
		output  +=  String.format("%.2f",this.health_status)+"\t";
		output  +=  String.format("%.2f",this.healthShock)+"\t";
		output  +=  String.format("%.2f",this.hce)+"\t";
		output  +=  Integer.toString(this.socialnetwork.size())+"\t";
		output  +=  String.format("%.2f", this.getAvgFromSN(3))+"\t";
		output  += 	String.format("%s", this.getAboveEducSN(12))+"\t";
		output  += 	String.format("%s", this.getAboveEducSN(16))+"\t";
		output  +=  Integer.toString(this.location.getListOfSchools(0, true,true).size())+"\t";
		output  +=  Integer.toString(this.location.getListOfSchools(6, true,true).size())+"\t";
		output  +=  Integer.toString(this.location.getListOfSchools(9, true,true).size())+"\t";
		output  +=  Integer.toString(this.location.getListOfSchools(12, true,true).size())+"\t";
		output  +=  String.format("%.3f",this.getInitialHealth())+"\t";
		output  +=  String.format("%.4f",this.location.hospital.delta_h)+"\t";
		output  +=  Integer.toString(this.getInheritedSNSize())+"\t";

		
		
		// Capabilities
		output += String.format("%s", Agent.boolean2int(this.capabDowngradeToPublic))+"\t";
		output += String.format("%s", Agent.boolean2int(this.capabFullRecoveryPossible))+"\t";
		output += String.format("%s", this.capabSNLostContacts)+"\t";
		output += String.format("%s", this.capabSNPossibleAdditions)+"\t";
		output += String.format("%s", this.educ_yearsCF)+"\t";
		output += String.format("%.2f", this.healthShockCF)+"\t";
		output += String.format("%.2f", this.human_capitalCF)+"\t";
		output +=  Integer.toString(this.socialnetworkCFAllIn.size())+"\t";
		output +=  Integer.toString(this.socialnetworkCFNoOut.size());
		
		
		return output;
		
		
		
	}
	
	/**
	 * Returns TRUE with the probability indicated in parameter 'probability' and FALSE in the complement of that probability. The method uses the RePast {@link RandomHelper RandomHelper} package and therefore takes into 
	 * account the random seed set by the simulation engine. 
	 * @param probability
	 * @return boolean (TRUE/FALSE)
	 */
	public boolean getRandomBoolean(double probability) {
		double x = RandomHelper.nextDoubleFromTo(0,1);
		if(x<probability){
			return true;
		}
		else{
			return false;
		}
		
	}
	
	/**
	 * Returns the size of the inherited social network
	 * @return
	 */
	private int getInheritedSNSize() {
		return this.initialSNSize;
	}


	/**
	 * Returns the initial health (upon birth)
	 * @return
	 */
	private double getInitialHealth() {
		return this.initialHealth;
	}


	private int getAboveEducSN(int minEduc) {
		int N = 0;
		
		for(Individual partner:this.socialnetwork.keySet()){ 
			if(partner.educ_years>=minEduc){
				N++;
			}
					
			
		}
		return N;
	}


	/**
	 * Returns the years of education of the father if available and -1 otherwise
	 * @return
	 */
	private int getFeduc() {
		if(this.father!=null){
			return this.father.educ_years;
		}
		else{
			return -1;
		}
	}
	
	
	/**
	 * Returns the years of education of the mother if available and -1 otherwise
	 * @return
	 */
	private int getMeduc() {
		if(this.mother!=null){
			return this.mother.educ_years;
		}
		else{
			return -1;
		}
	}


	/**
	 * Return the quality of the school to which the child goes. If not enrolled, the value of -1 is returned
	 * @return -1 if no school, school quality otherwise
	 */
	private double getSchoolQuality() {
		if(this.school!=null){
			return this.school.quality;
		}
		else{
			return -1.0;
		}
	}
	
	/**
	 * Returns 1 if the individual engages in risky behaviour and 0 otherwise
	 * @return binary indicator for risky behaviour
	 */
	public int getRiskyBehaviour(){
		return boolean2int(this.risky_behaviour);
	}
	
	

}


