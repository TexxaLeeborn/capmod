package sEM2;




import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Formatter;
import java.util.Vector;

import repast.simphony.context.Context;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.engine.environment.RunState;
import repast.simphony.engine.schedule.ScheduledMethod;
import repast.simphony.parameter.Parameters;
import repast.simphony.parameter.Schema;
import repast.simphony.util.ContextUtils;

public class Model {
	
	/**
	 * Array with the tuition fee (and other cost) for each level of schooling. The first element (index=0) is for public schools (all levels)
	 * For indexes 1-4 we have all level of private schooling, starting at primary and up to university 
	 */
	public static final int[] tuition = {0,12000,20000,30000,100000};
	private static int startDataOutput;
	
	
	
	
	//public static double[][] school_delta = {{0.1, 0.2, 0.3, 0.4},{0.6, 0.7, 0.8, 0.9}};
	/**
	 * Array of the school Psi's. The order is public schools for index 0-3 with increasing level (prim, ls, us, tert) and then for index 4-7 the same for private schools. 
	 */
	public static double[] psiS = new double[8];
	
	
	
	
	
	
	
	
	
	
	public static Context context = null;
	public static int count_passed = 0;
	public static int count_failed = 0;
	public static int count_mating_success = 0;
	public static int count_mating_attempts =0;
	public static double fertility_inflator=0.8;
	public static int counter_famid=1;
	public static int counter_indiv=1;
	
	public static int count_birth = 0;
	public static int count_death = 0;
	public static Vector<Location> locations; // = new Vector<Location>();
	
	
	public Model(){
		count_passed = 0;
		count_failed = 0;
		count_mating_success = 0;
		count_mating_attempts =0;
		fertility_inflator=0.8;
		counter_famid=1;
		counter_indiv=1;
		
		count_birth = 0;
		count_death = 0;
		locations = new Vector<Location>();
		
		if(RunEnvironment.getInstance().isBatch()==true){
			Model.startDataOutput=60;
		}
		else{
			Model.startDataOutput=1;
		}
		
		
		updateParmeters();
		
	}
	
	@ScheduledMethod(start=1,interval=1,priority=99) //Step: 99 Model.stepCleanData()
	public void stepCleanData(){
		
		count_passed=0;
		count_failed=0;
		count_mating_success = 0;
		count_mating_attempts=0;
		count_birth=0;
		count_death=0;
		double tick = RunEnvironment.getInstance().getCurrentSchedule().getTickCount();
		if(RunEnvironment.getInstance().isBatch() && tick%10==0 ){
			System.out.printf("Run %s => Tick %s\n",RunState.getInstance().getRunInfo().getRunNumber(), tick);
		}
		
	}
	
	
	@ScheduledMethod(start=1, interval=1, priority=1,shuffle=true) // Step: 01 Model.stepSummariseTick()
	public void stepSummariseTick(){
			
		if(RunEnvironment.getInstance().getCurrentSchedule().getTickCount()>=Model.startDataOutput){
		// Set output path
		String basepath;
		String batchnum;
		String batchName = "Single";
		if(RunEnvironment.getInstance().isBatch()){
			basepath = "C:/RepastData/SEM2/batch/"; 
			batchnum = "_"+RunState.getInstance().getRunInfo().getRunNumber();
			batchName = RunEnvironment.getInstance().getParameters().getString("batchName");
			
		}
		else{
			basepath = "C:/RepastData/SEM2/";
			batchnum = "";
		}
		
		// Output
		int tick = (int) RunEnvironment.getInstance().getCurrentSchedule().getTickCount();
		
		
		boolean append=true;
		if(tick==startDataOutput){
			append=false;
		}
		Context<Object> mycontext = ContextUtils.getContext(this);
		
		
		try {
		// FAMILY DATA EXPORT
			String path=basepath+batchName+"_family"+batchnum+".txt"; 
			
			FileOutputStream myfile_family;
			
			myfile_family = new FileOutputStream(path,append);
			
			Formatter output_family = new Formatter(myfile_family);
			
			// Header
			if(append==false){
				output_family.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n","Tick","FamID","Size","Location","savings","SavingsBefore","Income","Consumption","HCE","EducExp","MinConsumption","SchoolDecision","CapabIncomeAboveMin","CapabAblePayAllSchooling","CapabAblePayAllRecovery");
			}
			
			for(Object o:mycontext.getObjects(Family.class)){
				Family f = (Family)o;
				output_family.format("%s\t%s\t%s\t%s\t%s\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%8.2f\t%s\t%s\t%s\t%s\n",tick,f.ID,f.getFamilySize(),f.location.ID,f.savings,f.savings_before,f.income,f.consumption,f.hce,f.educ_exp,f.minconsumption,f.schoolingDecisionCase,Agent.boolean2int(f.capabIncomeAboveMin),Agent.boolean2int(f.capabAblePayAllSchooling),Agent.boolean2int(f.capabAblePayAllRecovery));
			
			}
			output_family.close();
			
			
		// INDIVIDUAL DATA EXPORT
			path=basepath+batchName+"_indiv"+batchnum+".txt"; 
			FileOutputStream myfile_indiv;
			
				myfile_indiv = new FileOutputStream(path,append);
			
			Formatter output_indiv = new Formatter(myfile_indiv);
			
			// Header
			if(append==false){
				output_indiv.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n","Tick","ID","FamID","Age","Enrolled","School","PrivateSchool","FailedGrades","FailedGradesLevel","HealthStatus","Shock","ShockCF","HCE","HumanCapital","HumanCapitalCF","IQ","LifeStatus","Personality","RiskyBehaviour","SNsize","SnAvgSalary","SnAvgEduc","SnAtLeastOneUpperSecondary","SnAtLeastOneCollege","SNsizeCFAllIn","SNsizeCFNoOut","Educ","EducCF","Nchildren","Female","DropoutReason","EducAspiration","OrgIndiv","Salary","Role","Comment","WillingContinue","Aspiration","ParentalAspiration","CapabFullRecoveryPossible","CapabDowngradeToPublic","CapabSNPossibleAdditions","CapabSNLostContacts","SchoolSize");
			}
			
			for(Object o:mycontext.getObjects(Individual.class)){
				Individual i = (Individual)o;
				//output_indiv.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",tick,i.hashCode(),i.family.hashCode(),i.age,i.isAtSchool(),i.failedgrades,i.health_status,i.human_capital,i.IQ,i.life_status,i.personality,Agent.boolean2int(i.risky_behaviour),i.getSNsize(),i.years_educ);
				output_indiv.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",tick,i.ID,i.family.ID,i.age,i.isAtSchool(),i.hasSchool(),i.privateSchool(),i.failedgrades,i.failedGradesLevel,i.health_status,i.healthShock,i.healthShockCF,i.hce,i.human_capital,i.human_capitalCF,i.IQ,i.life_status,i.personality,Agent.boolean2int(i.risky_behaviour),i.getSNsize(),i.getSNStats()[0],i.getSNStats()[1],i.getSNEducAtLeast(12),i.getSNEducAtLeast(16),i.getSNsize(i.socialnetworkCFAllIn),i.getSNsize(i.socialnetworkCFNoOut),i.educ_years,i.educ_yearsCF,i.n_children,i.isFemale(),i.reason_left_school,i.aspiration_educ,i.originalIndiv,i.salaryOfPeriod,i.getRole(),i.comment,Agent.boolean2int(i.willingContinueSchool),i.getAspiration(),i.getParentalAspiration(),Agent.boolean2int(i.capabFullRecoveryPossible),Agent.boolean2int(i.capabDowngradeToPublic),i.capabSNPossibleAdditions,i.capabSNLostContacts,i.getSchoolSize());
				
			}
			output_indiv.close();
			
			// SCHOOL DATA EXPORT
						path=basepath+batchName+"_schools"+batchnum+".txt"; 
						FileOutputStream myfile_school;
						
							myfile_school = new FileOutputStream(path,append);
						
						Formatter output_school = new Formatter(myfile_school);
						
						// Header
						if(append==false){
							output_school.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n","Tick","ID","Location","Capacity","Quality","Private","Tuition", "Enrollment","Level");
						}

						
						for(Object o:mycontext.getObjects(School.class)){
							School s = (School)o;
							//output_indiv.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",tick,i.hashCode(),i.family.hashCode(),i.age,i.isAtSchool(),i.failedgrades,i.health_status,i.human_capital,i.IQ,i.life_status,i.personality,Agent.boolean2int(i.risky_behaviour),i.getSNsize(),i.years_educ);
							output_school.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",tick,s.hashCode(),s.location.ID,s.capacity,s.quality,Agent.boolean2int(s.privateschool),s.tuition,s.students.size(),s.level);
							
						}
						output_school.close();
						
			// LOCALITY DATA EXPORT
						path=basepath+batchName+"_localities"+batchnum+".txt"; 

						FileOutputStream myfile_localities;
						
							myfile_localities = new FileOutputStream(path,append);
						
						Formatter output_localities = new Formatter(myfile_localities);
						
						// Header
						if(append==false){
							output_localities.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n","Tick","Location","LocationName","Xcoord","Ycoord","Type","Nschools","NSchoolsPrimary","NSchoolsSecondary","NSchoolsHighSchool","NSchoolsTertiary","QualityHospital");
						}

						
						for(Object o:mycontext.getObjects(Location.class)){
							Location l = (Location)o;
							//output_indiv.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",tick,i.hashCode(),i.family.hashCode(),i.age,i.isAtSchool(),i.failedgrades,i.health_status,i.human_capital,i.IQ,i.life_status,i.personality,Agent.boolean2int(i.risky_behaviour),i.getSNsize(),i.years_educ);
							output_localities.format("%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n",tick,l.ID,l.name,l.xcoord,l.ycoord,l.type,l.schools.size(),l.getNumberOfSchools(1),l.getNumberOfSchools(2),l.getNumberOfSchools(3),l.getNumberOfSchools(4),l.hospital.delta_h);
							
						}
						output_localities.close();
		} 
		catch (FileNotFoundException e) {
			System.out.println("I have a file not found exception");
			System.exit(1);
		}
		if(tick%60==0){
			RunEnvironment.getInstance().pauseRun();
		}
		} // end if really outputs
		
		
} // EndSummariseTick
	
	@ScheduledMethod(start=1,interval=1, priority=1) // Step: 01 Model.stepExportSEMData()
	public void stepExportSEMData(){
	//System.out.printf("Context size = %s\n",Model.context.size());
		
		// Output
		
		int tick = (int) RunEnvironment.getInstance().getCurrentSchedule().getTickCount();
		if(!RunEnvironment.getInstance().isBatch()){
		System.out.printf("================== SUMMARY FOR TICK %s ==================\n",  tick);
		System.out.printf("N(births): %s; N(deaths): %s\n",count_birth,count_death);
		}
		if(tick>1){
			double thetaPop = RunEnvironment.getInstance().getParameters().getDouble("thetaPop"); 
			//Model.fertility_inflator = Math.max(0.2, Math.min(3,Model.fertility_inflator * ((double)count_death/(double)count_birth)));
			//Model.fertility_inflator = Math.max(0.2, Math.min(3,Model.fertility_inflator * ((double)300/(double)(count_birth))));
			Model.fertility_inflator = Math.max(0.2, Math.min(3,Model.fertility_inflator * (1+thetaPop)*((double)count_death/(double)(count_birth))));
		}
		boolean append=true;
		if(tick==1){
			append=false;
		}
		Context<Object> mycontext = ContextUtils.getContext(this);
		//System.out.printf("The size of the context is now %s\n\n------------------",mycontext.size());
		
		try {
		
			
			
			
		// INDIVIDUAL DATA EXPORT
			String path="C:/RepastData/SEM2/data_SEM.txt"; 
			
			// Add the run number to the name
			if(RunEnvironment.getInstance().isBatch()){
				String	batchName = RunEnvironment.getInstance().getParameters().getString("batchName");
				path = "C:/RepastData/SEM2/batch/"+batchName+"_SEM_"+RunState.getInstance().getRunInfo().getRunNumber()+".txt"; 
				
				
				if(RunEnvironment.getInstance().getCurrentSchedule().getTickCount()==1){
					// In the first period, we want to export all the parameters
					String pathMap = "C:/RepastData/SEM2/batch/"+batchName+"_paramMap_"+RunState.getInstance().getRunInfo().getRunNumber()+".txt"; 

					exportParameterMap(pathMap,RunEnvironment.getInstance().getParameters());
				}
			}
			
			
			
			FileOutputStream myfile_indiv;
			
				myfile_indiv = new FileOutputStream(path,append);
			
			Formatter output_indiv = new Formatter(myfile_indiv);
			
			// Header
			if(append==false){
				output_indiv.format("%s","Tick\tID\tAge\tNSchoolsPrimary\tNSchoolsSecondary\tNSchoolsHigh\tNSchoolsUni\tSavings\tIncome\tFamSize\tNSiblings\tFemale\tPrivSchool\tFailedGrades\tEduc\tHumanCapital\tIQ\tFeduc\tMeduc\tDropoutReason\tSchoolQuality\tHealthStatus\tHealthShock\tHCE\tSNsize\tSNAvgEduc\tSNEducHS\tSNEducUni\tnSchoolsPrim\tnSchoolsLS\tnSchoolsUS\tnSchoolsTer\tinitialHealth\tlevelHospital\tinitSNSize\tCapDowngrade\tCapFullRecovery\tCapSnLostContact\tCapSnPosAdd\teducCF\thealthShockCF\thumcapitalCF\tSnCFAllin\tSnCFNoOut\n");
			}
			
			for(Object o:mycontext.getObjects(Individual.class)){
				Individual i = (Individual)o;
				if(i.age<=25 && i.originalIndiv==0){				
				
					
					output_indiv.format("%s\t%s\n",tick,i.getDataForSEMExort());
				}
			}
			output_indiv.close();
			
		} 
		catch (FileNotFoundException e) {
			System.out.println("I have a file not found exception");
			System.exit(1);
		}
		
		
		if(tick%60==0){
			RunEnvironment.getInstance().pauseRun();
		}
		
		if(RunEnvironment.getInstance().isBatch()){
			RunEnvironment.getInstance().endAt(60);
		}
	
	}
	
	/**
	 * Method to export all parameters to an individual text-file. Uses a fixed list of parameters that will be exported, it does not automatically get all the parameters present in the file. 
	 * @param pathMap File path
	 * @param parameters parameter set of the simulation
	 */
	private void exportParameterMap(String pathMap, Parameters parameters) {
		
		FileOutputStream mymap_file;
		try {
			mymap_file = new FileOutputStream(pathMap,false);
			Formatter outputMap = new Formatter(mymap_file);
			
			
			String field="randomSeed,xiAge,gamma,alphaPrim,alphaUp,xi,phiRB,thetaPop,deltaInherit,deltaSnPlus,deltaSnMinus,deltaSnT,thetaSN,sigmaPers,sigmaH,thetaInc,thetaIncvar,deltaIn,tau,betaRural,betaUrban,deltaOut,phiRF,thetaM,psiS,phiH";
			String[] fields = field.split(",");
			
			outputMap.format("Run,%s\n",field);
			outputMap.format("%s",RunState.getInstance().getRunInfo().getRunNumber());
			for(String f:fields){
				outputMap.format(",%s",parameters.getValue(f));
			}
					
			outputMap.close();
			
		} catch (FileNotFoundException e) {
			System.out.printf("Sorry, I was not able to save the parameter map at: %s\n",pathMap);
			}
		
		
	}

	public double getMatingSuccessRatio(){
		return (double)count_mating_success / (double) count_mating_attempts;
	}
	
	public double getFailRate(){
		return (double)count_failed / ((double)count_failed + (double)count_passed);
	}
	
	public double getFertilityInflation(){
		return fertility_inflator;
	}
	
	/*
	 * Updates several parameters to the instance variables in Model.java. 
	 * 
	 */
	public static void updateParmeters(){
		
		// School deltas
		String[] values = RunEnvironment.getInstance().getParameters().getString("psiS").split(";"); 
		for(int i=0;i<8;i++){
			Model.psiS[i] = Double.parseDouble(values[i]); 
		}
	}
	
	
}
