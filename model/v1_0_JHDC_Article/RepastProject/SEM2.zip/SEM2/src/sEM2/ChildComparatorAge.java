package sEM2;

import java.util.Comparator;

public class ChildComparatorAge implements Comparator<Individual>{
	
	public int compare(Individual i1, Individual i2){
		int agediff = i1.age - i2.age;
		return agediff;		
	} // end compare
	

}
