package sEM2;


/**
 * This class is only used for testing purposes, for instance to perform unit testing. 
 * @author Florian 
 *
 */
public class Tester {

	
	
	public static void main(String[] args) {
	
		Individual me = new Individual(false, 10,100, 15, (float) 0.75);
	
		for(int i=0;i<1000;i++){
			System.out.printf("%s\n",me.getRandomBoolean(0.75));
		}
		
	}
}
