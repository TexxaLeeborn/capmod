package sEM2;

public class Hospital {
	protected Location location;
	protected double delta_h;
	
	
	
	/**
	 * Creates a new hospital
	 * @param city 	Location of the hospital (village)
	 * @param level for type of facility (0.1=outpatient doctor, 2=light hospital, 3=full hospital)
	 */
	public Hospital(Location city,double level){
		this.location 		= city;
		this.delta_h 		= level; 	//village: 0.002, middle: 0.003, capital: 0.005
		
		
		
		// Set this hospital as the hospital in the location
		this.location.hospital = this;
	}
	
	
	
	/**
	 * Retuns the cost of recovery in this particular facility
	 * @param recovery that should be achieved
	 * @return double recovery cost
	 */
	public double getCostTreatment(double recovery){
		return Math.pow(recovery/this.delta_h,2);
	}


	/**
	 * Returns the amount of recovery the hospital provides for the given investment
	 * @param investment
	 * @return recovery on health status scale
	 */
	public double treat(double investment) {
		if(investment<=0.0 || investment==Double.NaN){
			System.out.printf("I HAVE A NAN REQUEST AS INVESTMENT");
			System.exit(2);
			return 0.0;
		}
		else{
			return this.delta_h * Math.sqrt(investment); 
		}
	}
	
	
	
	
}
