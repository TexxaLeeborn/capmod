package sEM2;

import java.util.Comparator;

public class ChildComparatorTime2Grad implements Comparator<Individual>{
	
	public int compare(Individual i1, Individual i2){
		int graddiff = (int) Math.ceil(i1.timeToGraduation(true) - i2.timeToGraduation(true));
		if(graddiff<0){
			graddiff-=1;
		}
		return graddiff;		
	} // end compare
	

}