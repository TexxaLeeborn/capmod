package sEM2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Vector;

import repast.simphony.context.Context;
import repast.simphony.context.space.continuous.ContinuousSpaceFactory;
import repast.simphony.context.space.continuous.ContinuousSpaceFactoryFinder;
import repast.simphony.dataLoader.ContextBuilder;
import repast.simphony.engine.environment.RunEnvironment;
import repast.simphony.parameter.Parameters;
import repast.simphony.random.RandomHelper;
import repast.simphony.space.continuous.ContinuousSpace;
import repast.simphony.space.continuous.RandomCartesianAdder;

public class Initialiser implements ContextBuilder<Object>{
	
	
	
	

	@SuppressWarnings("unchecked")
	@Override
	public Context<Object> build(Context<Object> context){
		context.setId("SEM2");
		String inputDirectory = "C:/fwchj/research/papers/44_SEM_ABM_2/input_data/";

		//private static final float fertility[][] = new float[9][13];
		Family currentfamily = null; 
		Vector<Family> allfamilies = new Vector<Family>();
		float ydim=50;
		float xdim=50;
		
		ContinuousSpaceFactory spaceFactory = ContinuousSpaceFactoryFinder.createContinuousSpaceFactory(null);
		ContinuousSpace<Object> space = spaceFactory.createContinuousSpace("space",context,
				new RandomCartesianAdder<Object>(),new repast.simphony.space.continuous.StrictBorders(),xdim, ydim);
		
		//NetworkBuilder <Object > netBuilder = new NetworkBuilder <Object > ("social network", context , false );
		//netBuilder . buildNetwork ();
	
		Parameters params = RunEnvironment.getInstance().getParameters();
		
		Agent.space = space;
		// Add a generic Model-Class
		//context.add(new Model());
		
		
		// LOAD FERTILITY MATRIX (For the initialisation)
		String path = inputDirectory +"input_mincer.csv";
		Scanner scanner = null;
		
		try {
			scanner = new Scanner(new BufferedReader(new FileReader(path)));
		} catch (FileNotFoundException e) {
			System.out.println("I could not find the file input_mincer.csv");
			e.printStackTrace();
			
		}
		
		
		scanner.useDelimiter(",");
		scanner.nextLine();
		
		for(int row=0;row<=12;row++){
			scanner.next();
			for(int col=0;col<=3;col++){
				float value = (float) Float.parseFloat(scanner.next());
				//System.out.printf("[%s,%s] = %s", row,col,value);
				Agent.mincer[row][col] = value;
		}
		//System.out.print("\n");
		}
		scanner.close();
		
		
		//System.out.printf("The:\n%s",Arrays.toString(fertility));
		
		// LOAD PROCREATION PROBABILITY MATRIX (for the running simulation)
				path = inputDirectory+"input_procreation_probabilities.csv";
				scanner = null;
				
				try {
					scanner = new Scanner(new BufferedReader(new FileReader(path)));
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
				
				scanner.useDelimiter(",");
				scanner.nextLine();
				
				// Fill in the first part with zero probability
				for(int row=0;row<=14;row++){
					for(int col=0;col<=8;col++){
						Agent.prob_child[row][col]=0;
					}
				}
				
				for(int row=15;row<=45;row++){
					scanner.next();
				for(int col=0;col<=8;col++){
						float value = Float.parseFloat(scanner.next());
						//System.out.printf("[%s,%s] = %s\n", row,col,value);
						Agent.prob_child[row][col]= value;
				}
				scanner.nextLine();
				
				}
				scanner.close();
				
				//System.out.printf("The procreation probability matrix is is:\n%s",Arrays.toString(Agent.prob_child));
		
				Model model = new Model();
				context.add(model);
				Model.context=context;
		
		// LOAD VILLAGE TYPES FROM FILE
		// vectors of variables
		boolean[] 	privschool 	= {false,true,false,true,false,true,false,true};
		int[]		schooltype	= {1,1,2,2,3,3,4,4};
		float[] 	tution		= {Model.tuition[0],Model.tuition[1],Model.tuition[0],Model.tuition[2],Model.tuition[0],Model.tuition[3],Model.tuition[0],Model.tuition[4]};
	 
		
		
		
		// Load data from file
		//String path = params.getValueAsString("inputFile");
		 path = inputDirectory+"location_types.csv";
		 scanner = null;
		
		try {
			scanner = new Scanner(new BufferedReader(new FileReader(path)));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		scanner.useDelimiter(",");
		scanner.nextLine();
		int ID=1;
		HashMap<Integer,Location> locations = new HashMap<Integer,Location>();
		
		while(scanner.hasNextLine()){

			// Load data
			int type 				= Integer.parseInt(scanner.next());
			String name 			= scanner.next();
			int population 	 		= Integer.parseInt(scanner.next());
			int S_L1_pu				= Integer.parseInt(scanner.next());
			int S_L1_pr				= Integer.parseInt(scanner.next());
			int S_L2_pu				= Integer.parseInt(scanner.next());
			int S_L2_pr				= Integer.parseInt(scanner.next());
			int S_L3_pu				= Integer.parseInt(scanner.next());
			int S_L3_pr				= Integer.parseInt(scanner.next());
			int S_L4_pu				= Integer.parseInt(scanner.next());
			int S_L4_pr				= Integer.parseInt(scanner.next());
			
			int schools[] 			= {S_L1_pu,S_L1_pr,S_L2_pu,S_L2_pr,S_L3_pu,S_L3_pr,S_L4_pu,S_L4_pr};
			
			//System.out.printf("School vector:%s",Arrays.toString(schools));
			scanner.nextLine();
				
			// Adapt Data
			double x = 3+ RandomHelper.nextDoubleFromTo(0, 1) * (xdim-6);
			double y = 3+ RandomHelper.nextDoubleFromTo(0, 1) * (ydim-6);
			
			
			// Add the location
			Location thislocation = new Location(ID,name,type,x,y,space);
			context.add(thislocation);
			Model.locations.add(thislocation);
			
			space.moveTo(thislocation, x,y);
			
			locations.put(type, thislocation);
			
			ID++;
			
			// ADD THE HOSPITALS
			String[] phiH = params.getString("phiH").split(";");
			//System.out.printf("phiH Array: %s\n", Arrays.toString(phiH));
			
			double level = Double.parseDouble(phiH[1]);
			if(type==1){
				level = Double.parseDouble(phiH[0]);
			}
			else if(type==4){
				level=Double.parseDouble(phiH[2]);
			}
			
			//System.out.printf("=> the hospital level is:%s\n",level);
			
				
			Hospital newhosp = new Hospital(thislocation, level);
			context.add(newhosp);
			
			space.moveTo(newhosp,thislocation.xcoord, thislocation.ycoord);
			
		
			
			 for(int j=0;j<8;j++){
				int N = schools[j];
				
				for(int i = 1;i<=N;i++){
					float quality = School.getRandomSchoolQuality( privschool[j],schooltype[j]); 
					School newschool = new School(thislocation, 100, quality, privschool[j], tution[j], schooltype[j]);
					thislocation.schools.add(newschool);
					context.add(newschool);
					
					float xcoord = (float) Math.min(49.99,Math.max(0,thislocation.xcoord + RandomHelper.createNormal(0, Math.log(population)/10).nextDouble()));
					float ycoord = (float) Math.min(49.99,Math.max(0,thislocation.ycoord + RandomHelper.createNormal(0, Math.log(population)/10).nextDouble()));
					space.moveTo(newschool,xcoord, ycoord);
					
				} // end of loop through schools of same type
			  }	// end of loop through school types
			
		
			 
			
			
			 
			
			
			
		}
		
		scanner.close();
		
		
		
		
		
		// Add population
		// Load data from file
		//String path = params.getValueAsString("inputFile");
		 path = inputDirectory + "/input_population_sample.csv";
		  scanner = null;
		
		try {
			scanner = new Scanner(new BufferedReader(new FileReader(path)));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		scanner.useDelimiter(",|\\n");
		scanner.nextLine();
		
		int current_loc_type = 0;
		int current_folio = 0;
		Location current_location = null;
		
		int location_type=0;
		int folio = 0;
		int role = 0;
		int age = 0;
		float iq = (float) 0.0;
		boolean female = true;
		int educ = 0;
		boolean cont = true;
		int school_type=0;
		
		
		
		while(scanner.hasNextLine()){

			// Load data of the father
			if(location_type==0 && folio==0){ // first family)
				location_type		= Integer.parseInt(scanner.next());
				folio 	 			= Integer.parseInt(scanner.next());
				role	 	 		= Integer.parseInt(scanner.next());
				age					= Integer.parseInt(scanner.next());
				iq					= Float.parseFloat(scanner.next());
				female				= Agent.Int2Boolean(Integer.parseInt(scanner.next()));
				educ				= Integer.parseInt(scanner.next());
				school_type 		= Integer.parseInt(scanner.next().trim());
				
			}
			
			float personality 		= (float)RandomHelper.nextDoubleFromTo(0,1);
			Individual father = new Individual(false,age,iq,educ,personality);
			father.originalIndiv=1;
			father.life_status=3;
			current_folio = folio;
			// CHECK IF NEW LOCATION
			//System.out.printf("I read: %s,%s,%s,%s,%s,%s,%s\n",location_type,folio,role,age,iq,female,educ);
						if(location_type!=current_loc_type){
							current_location = locations.get(location_type);
							current_loc_type= location_type;
							//System.out.printf("\n===>NEW LOCATION: %s (%s)\n ",current_location.type,current_location.name);

						}
			
			
			
			scanner.next(); // skip location for mother
			scanner.next(); // skip folio
			role	 	 		= Integer.parseInt(scanner.next());
			age					= Integer.parseInt(scanner.next());
			iq					= Float.parseFloat(scanner.next());
			female				= Agent.Int2Boolean(Integer.parseInt(scanner.next()));
			educ				= Integer.parseInt(scanner.next());
			school_type 		= Integer.parseInt(scanner.next().trim());
			
			Individual mother = new Individual(true,age,iq,educ,Agent.newPersonality(personality));
			mother.originalIndiv=1;
			mother.life_status=3;
			context.add(father);
			context.add(mother);
			Family myfamily = new Family(current_location,mother,father,0.0);
			
			father.income = father.getSalary(true);
			mother.income = mother.getSalary(true);
			father.location=current_location;
			mother.location=current_location;
			allfamilies.add(myfamily);
			currentfamily = myfamily;
			context.add(myfamily);
			
			// move family 
			float xcoord = (float) Math.min(xdim-0.01,Math.max(0,current_location.xcoord + RandomHelper.createNormal(0, 1).nextDouble()));
			float ycoord = (float) Math.min(xdim-0.01,Math.max(0,current_location.ycoord + RandomHelper.createNormal(0, 1).nextDouble()));
			
			space.moveTo(myfamily,xcoord, ycoord);
			space.moveTo(father,xcoord, ycoord);
			space.moveTo(mother,xcoord, ycoord);
			
			
			
			
			
			cont=true;
			while(cont){
				scanner.nextLine();
				
				if(scanner.hasNext()){
				location_type		= Integer.parseInt(scanner.next());
				folio 	 			= Integer.parseInt(scanner.next());
				role	 	 		= Integer.parseInt(scanner.next());
				age					= Integer.parseInt(scanner.next());
				iq					= Float.parseFloat(scanner.next());
				female				= Agent.Int2Boolean(Integer.parseInt(scanner.next()));
				educ				= Integer.parseInt(scanner.next());
				school_type 		= Integer.parseInt(scanner.next().trim());
				if(folio==current_folio){
					Individual child = new Individual(female,age,iq,educ,Agent.newPersonality(father.personality,mother.personality));
					child.mother = mother;
					child.father = father;
					child.originalIndiv=1;
					mother.n_children++;
					child.location=current_location;
					if(school_type>0){
					Vector<School> availableSchools =new Vector<School>();
					if(school_type==2){ // searching private schools
						availableSchools= current_location.getListOfSchools(child.educ_years,true,false);
					}
					else if(school_type==1 || (availableSchools.size()==0 & school_type==2)){
						availableSchools = current_location.getListOfSchools(child.educ_years,false,true);
					}
					int runner=0;
					boolean cont2=true;
					if(availableSchools.size()>0){
					while(cont2){
						School currentschool = availableSchools.get(runner);
						if(currentschool.enroll(child)==true){
							cont2=false;
							child.school=currentschool;
							//System.out.printf("\t School %s accepted child %s\n",currentschool.toString(),child.toString());
						}
						else{
							//System.out.printf("\t School %s REJECTED child %s\n",currentschool.toString(),child.toString());
							runner++;
							if(runner>=availableSchools.size()){
								cont2=false;
								//System.out.printf("\t =>WE COULD NOT FIND ANY SCHOOL FOR THIS CHILD!!!!\n");
							}
							
						}
						}
					} // end if availableSchools>0
					
						
					} // end if school type>0
					
					
					
					
					myfamily.addChild(child);
					child.family 			= myfamily;
					child.familyOriginal 	= myfamily;
					child.setAspirations(); // Only needed in the initialisation
					context.add(child);
					space.moveTo(child,xcoord, ycoord);
					//System.out.printf("\t\t I am supposed to add a child\n");
				}
				else{
					cont=false;
					
					}
				}
				else{
					cont=false;
					//System.out.printf("***I finished the input file for the population without error***\n");
				}
				
			}
			
			
		
			
			
			
			
			
		
		} // end while scanner has a next line
		
	
		
		scanner.close();
		
		
		
		//System.out.printf("The number of families is: %s\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\nXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",allfamilies.size());
		
		// Set-up the initial social network
		int N_ties = 0;
		double prop=0;
		
		for(int i=0; i< allfamilies.size(); i++){
			Family thisfamily = allfamilies.get(i);
			//System.out.printf("Setting social network of family %s\n",thisfamily.toString());
			
			// Loop through all candidates
			for(int j=0;j<allfamilies.size();j++){
				Family candidate = allfamilies.get(j);
				if(thisfamily!=candidate){
					
					if(thisfamily.location==candidate.location){
						prop = params.getDouble("deltaIn");
					}
					else{
						prop = params.getDouble("deltaOut");

					}
					
					
					// This is a candidate
					if(RandomHelper.nextDoubleFromTo(0, 1)<prop){
						/*System.out.println("My current family is:");
						thisfamily.describe();
						System.out.printf("This family will be added to the social network of my family:\n");
						candidate.describe();
						System.out.println("--------------");
*/
												
						Vector<Individual> candidate_members = new Vector<Individual>();
						candidate_members = (Vector<Individual>) candidate.children.clone();
						candidate_members.add(candidate.father);
						candidate_members.add(candidate.mother);
						
						for(Individual cur_partner:candidate_members){
							
							if(cur_partner==null){
								System.out.printf("Oops, current partner is NULL\n");
							}
							thisfamily.father.addSocialTie(cur_partner);
							thisfamily.mother.addSocialTie(cur_partner);
							
							//net.addEdge(thisfamily.mother,cur_partner);
							N_ties+=2;
							for(Individual cur_child: thisfamily.children) {
								cur_child.addSocialTie(cur_partner);
								N_ties++;
								
								// Add display 
								
								//net.addEdge (cur_child , cur_partner );
							}
						}
						
						
						
					} // end if random<prop (=> match)
					
				} // end: if thisfamily!=candidate
				
			} // end: Loop through all other families  
			
			
			/*// Copy the actual social network to the counter-factual social networks
				//Father
				thisfamily.father.socialnetworkCFAllIn = (HashMap<Individual, Double>) thisfamily.father.socialnetwork.clone();
				thisfamily.father.socialnetworkCFNoOut = (HashMap<Individual, Double>) thisfamily.father.socialnetwork.clone();
			
				//Mother
				thisfamily.mother.socialnetworkCFAllIn = (HashMap<Individual, Double>) thisfamily.mother.socialnetwork.clone();
				thisfamily.mother.socialnetworkCFNoOut = (HashMap<Individual, Double>) thisfamily.mother.socialnetwork.clone();
			
				// Children
				for(Individual cur_child: thisfamily.children) {
					cur_child.socialnetworkCFAllIn = (HashMap<Individual, Double>) cur_child.socialnetwork.clone();
					cur_child.socialnetworkCFNoOut = (HashMap<Individual, Double>) cur_child.socialnetwork.clone();
				}*/
			
			
	    }	// end loop through families looking for a partner
			
			//System.out.printf("\n\nIn total we have %s social ties\n", N_ties);
		
			
		// Create the counter-factual social networks
			for( Object o:context.getObjects(Individual.class)){
				Individual i = (Individual) o;
				i.socialnetworkCFAllIn = (HashMap<Individual, Double>) i.socialnetwork.clone();
				i.socialnetworkCFNoOut = (HashMap<Individual, Double>) i.socialnetwork.clone();
			}
		
		
		
		// Compute context-size
		
		int size = context.size();
		//Agent.PrintMatrix(Agent.prob_child);
		//System.out.printf("MINCER MATRIX:\n");
		//Agent.PrintMatrix(Agent.mincer);
		//System.out.printf("CONEXT BUILT. It contains %s elements",size);
		
		
		
		/*
		
		System.out.println("LIST OF INDIVIDUALS WITH WRONG SOCIAL NETWORKS");
		for( Object o:context.getObjects(Individual.class)){
			Individual i = (Individual) o;
				if(i.socialnetwork.size()!=i.socialnetworkCFAllIn.size() | i.socialnetwork.size()!=i.socialnetworkCFNoOut.size()){
					System.out.printf("ID:%s\t SNsize:%s\t SNsizeCFAllIn:%s\t SNsizeCFNoOut:%s\n", i.ID,i.socialnetwork.size(),i.socialnetworkCFAllIn.size(),i.socialnetworkCFNoOut.size());

				}
		}
		System.out.println("----- END OF LIST -----");
		*/
		
		
		// TEST
		//Individual f = new Individual(false, 35,(float) 100.1, 10,(float) 0.5,true);
		//Individual m = new Individual(true, 35,(float) 100.1, 10,(float) 0.5,true);
		//Individual c1 = new Individual(f,m);
	/*
		for( Object o:context.getObjects(Family.class)){
			Family fam = (Family) o;
			if(fam.ID == 958){
				System.out.println("");
				fam.describeShort();
			}
		}
		
		
			
		
		
		System.out.println();
		for(Location loc:Model.locations){
			loc.describe();
		}
		*/
		
		
		


		return context;
	}

	/*private int drawNumberOfChildren(int m_educ) {
		
		int educLevel = Agent.educYearToLevel(m_educ);
		
		double x = RandomHelper.nextDoubleFromTo(0, 1);
		int num= 0;
		
		
		for(int i = 0;i<=11;i++){
			//System.out.printf("\t\t %s:Cum-Sum: %s vs x=%s\n",i,fertility[educLevel][i],x);
			if(x>fertility[educLevel][i]){
				num=i+1;
			}
		}
		
		
		//System.out.printf("\t==> Mother with educ=%s (level=%s) has %s children\n",m_educ,educLevel,num);
		return num;
	}*/
	

	

}
