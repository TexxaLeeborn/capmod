package sEM2;

import java.util.Comparator;

public class ChildComparatorEconGain implements Comparator<Individual>{
	
	public int compare(Individual i1, Individual i2){
		float econgain1 = i1.school.tuition + i1.getSalary(false);
		float econgain2 = i2.school.tuition + i2.getSalary(false);
		int econdiff = (int) Math.ceil(econgain1-econgain2);
		if(econdiff<0){
			econdiff-=1;
		}
		return econdiff;		
	} // end compare
	
	
}